import collections, hashlib, json, pathlib, re, shutil, subprocess, tempfile, zipfile, sys
repo = pathlib.Path('/private/tmp/wanderer-m405-b2-runtime')
base = '6b68bf563833fb31fbb8df4b15034f3fd26f60da'
godot = pathlib.Path('/Applications/Godot.app/Contents/MacOS/Godot')
work = pathlib.Path(tempfile.mkdtemp(prefix='wanderer-b2-focused-'))
pathlib.Path('/private/tmp/wanderer-m405-b2-focused-location').write_text(str(work))
source = work / 'source'
source.mkdir()
paths = subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard'],cwd=repo).decode().strip('\0').split('\0')
manifest = {}
for name in sorted(set(paths)):
    if '/evidence/' in name or name.startswith(('docs/', 'art/')):
        continue
    target = source/name
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(repo/name,target)
    manifest[name] = hashlib.sha256(target.read_bytes()).hexdigest()
(work/'source-sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
proof = 'tests/actors/m4_05_playable_authority_proof.gd'
recovery = repo/'tests/actors/evidence/m4-05b/b1'
with zipfile.ZipFile(recovery/'recovery-01/tested-source.zip') as archive:
    smoke_bytes = archive.read(proof)
smoke_hash = hashlib.sha256(smoke_bytes).hexdigest()
if smoke_hash != (recovery/'recovery-05/ABC/smoke-harness-sha256.txt').read_text().strip():
    sys.exit('smoke harness provenance mismatch')
smoke = work / 'original-smoke.gd'
smoke.write_bytes(smoke_bytes)
records = []
context = {'base_sha':base,'project':str(source),'output':str(work),'godot':str(godot),
           'godot_sha256':hashlib.sha256(godot.read_bytes()).hexdigest(),'smoke_source_sha256':smoke_hash,
           'expanded_source_sha256':manifest[proof], 'manifest':str(work/'source-sha256.json')}
(work/'context.json').write_text(json.dumps(context,indent=2)+'\n')
def stage(label,args,expected_checks=None):
    engine = work / (label+'.engine.log')
    report = work / (label+'-report.json')
    command = [str(godot),'--headless','--path',str(source),'--log-file',str(engine),*args]
    if expected_checks is not None:
        command += ['--','--report='+str(report)]
        if label in ('D','E'): command += ['--gate='+label]
    proc = subprocess.run(command, cwd=source, capture_output=True, timeout=100)
    (work/(label+'.stdout.log')).write_bytes(proc.stdout)
    (work/(label+'.stderr.log')).write_bytes(proc.stderr)
    (work/(label+'.exit')).write_text(str(proc.returncode)+'\n')
    patterns = re.compile(r'(?:^|\s)(?:SCRIPT ERROR|ERROR|Parse Error|FATAL):', re.I | re.M)
    errors = sorted({line.strip() for stream in [proc.stdout,proc.stderr,engine.read_bytes() if engine.exists() else b'']
                     for line in stream.decode(errors='replace').splitlines() if patterns.search(line)})
    j = json.loads(report.read_text()) if report.exists() else {}
    checks = len(j.get('checks',[]))
    failures = sum(not c.get('passed',False) for c in j.get('checks',[]))
    ok = proc.returncode == 0 and not errors and (expected_checks is None or (j.get('status')=='PASS' and not failures and (expected_checks=='B2 matrix' or checks==expected_checks)))
    if label == 'version':
        ok = ok and proc.stdout.decode().strip() == '4.7.2.stable.official.ed1daf0bf'
    actual = {'exit':proc.returncode,'unexpected_errors':errors,'checks':checks if j else None,'failures':failures if j else None,'report_status':j.get('status')}
    if label == 'B2':
        actual['classifications'] = dict(collections.Counter(c['classification'] for c in j.get('checks',[])))
        actual['deferred_dependencies'] = len(j.get('deferred',[]))
    records.append({'stage':label,'command':command,'expected':{'exit':0,'unexpected_errors':0,'checks':expected_checks},'actual':actual,'status':'PASS' if ok else 'HOLD'})
    (work/'results.json').write_text(json.dumps(records,indent=2)+'\n')
    print(label,records[-1]['status'], actual,flush=True)
    if not ok:
        print(work,flush=True)
        sys.exit(1)

stage('version',['--version'])
stage('import',['--editor','--import'])
for p in sorted(source.glob('scripts/m4/playable_*.gd'))+[source/proof,source/'tests/actors/m4_05_playable_effect_proof.gd']:
    stage('parse-'+p.stem,['--check-only','--script','res://'+str(p.relative_to(source))])
stage('B-smoke',['--script',str(smoke)],86)
stage('C-expanded',['--script','res://'+proof],97)
stage('D',['--script','res://'+proof],1846)
stage('E',['--script','res://'+proof],354)
stage('B2',['--script','res://tests/actors/m4_05_playable_effect_proof.gd'],'B2 matrix')
print(work,flush=True)
