import json, pathlib, subprocess, tempfile, sys, tarfile, shlex, hashlib
repo = pathlib.Path('/private/tmp/wanderer-m405-b2-runtime')
godot = '/Applications/Godot.app/Contents/MacOS/Godot'
base = '6b68bf563833fb31fbb8df4b15034f3fd26f60da'
historical = '1728c5e678c5065278d1251d50449a8820eb5dae'
old = json.loads((repo/'tests/actors/evidence/m4-05b/b1/recovery-05/F/run-record.json').read_text())
if len(sys.argv) == 1:
    work = pathlib.Path(tempfile.mkdtemp(prefix='wanderer-b2-combat-'))
    pathlib.Path('/private/tmp/wanderer-m405-b2-combat-location').write_text(str(work))
    stages = [('reference44', historical, 0), ('canonical94', base, 1)]
else:
    work = pathlib.Path(sys.argv[1])
    stages = [('candidate94', base, 2)]
for label, commit, template in stages:
    source = work / (label + '-source') if template != 2 else repo
    if template != 2:
        subprocess.run(['git', 'worktree', 'add', '--detach', str(source), commit], cwd=repo, check=True)
    output = work / label
    command = ['python3', str(source/'tests/combat/verify.py'), '--godot', godot, '--output', str(output)]
    flags = old[template]['command'][6:]
    if '--cutover-baseline' in flags:
        flags = flags[:-1] + [str(work/'reference44')]
    command.extend(flags)
    git_paths = subprocess.check_output(['git','ls-tree','-rz','--name-only',commit,'--','scripts','scenes','tests','assets','project.godot'],cwd=repo).decode().strip('\0').split('\0')
    if template == 2:
        git_paths += ['scripts/m4/playable_effect_rules.gd', 'scripts/m4/playable_effect_rules.gd.uid', 'tests/actors/m4_05_playable_effect_proof.gd', 'tests/actors/m4_05_playable_effect_proof.gd.uid']
    manifest = {p: hashlib.sha256((source/p).read_bytes()).hexdigest() for p in sorted(set(git_paths)) if '/evidence/' not in p and (source/p).is_file()}
    (work/(label+'-source.json')).write_text(json.dumps(manifest, indent=2)+'\n')
    print(shlex.join(command), flush=True)
    with (work/(label+'.stdout.log')).open('w') as out, (work/(label+'.stderr.log')).open('w') as err:
        exit_code = subprocess.run(command,cwd=source,stdout=out,stderr=err).returncode
    result = {'stage':label, 'base_sha':commit, 'expected_stages':old[template]['expected_stages'], 'cwd':str(source), 'command':command, 'exit':exit_code, 'results':str(output/'results.json')}
    (work/(label+'-command.json')).write_text(json.dumps(result,indent=2)+'\n')
    print(label, exit_code, flush=True)
    if exit_code: sys.exit(exit_code)
