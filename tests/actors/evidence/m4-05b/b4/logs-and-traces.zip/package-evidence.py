import collections, hashlib, json, pathlib, re, subprocess, zipfile
w=pathlib.Path.cwd()
p=pathlib.Path('/private/tmp/wanderer-b4-verification')
e=w/'tests/actors/evidence/m4-05b/b4'
engine='/Applications/Godot.app/Contents/MacOS/Godot'
b3=json.loads((e/'../b3/runtime/results.json').read_text())
report=json.loads((p/'b4-final.report.json').read_text())
assert (p/'b4-final.exit').read_text().strip()=='0'
assert all(x['passed'] for x in report['checks'])
def sha(f):
    h=hashlib.sha256()
    with open(f,'rb') as inp:
        for block in iter(lambda:inp.read(1024*1024),b''):h.update(block)
    return h.hexdigest()
def write(name,obj):
    (e/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
def read_report(name):
    return json.loads((p/(name+'.report.json')).read_text())
runs={}
for n in ['base','candidate']:
    for suite in ['smoke','expanded','schema','transactions','effects','lifecycle']:
        name=n+'-'+suite
        j=read_report(name)
        fails=[x for x in j['checks'] if not x['passed']]
        runs[name]={'status':j['status'],'assertions':len(j['checks']),'failures':fails,'exit':int(j['status']!='PASS')}
def labels(name):
    return collections.Counter(x['label'] for x in read_report(name)['checks'])
assert labels('base-schema')==labels('candidate-schema')
combat={}
traces=[]
for n in ['reference44','canonical94','candidate94']:
    d=p/n
    j=json.loads((d/'results.json').read_text())
    assert all(x['status']=='PASS' for x in j)
    traces.append(json.loads((d/'presentation-traces.json').read_text()))
    combat[n]={'execution':json.loads((p/(n+'.json')).read_text()),'stage_count':len(j),'stages':j}
assert traces[0]==traces[1]==traces[2]
commands=[]
for stage in b3['focused_stages']:
    if stage['stage'] not in ['original-smoke','expanded','schema','transactions','effects','lifecycle']:continue
    n={'original-smoke':'smoke'}.get(stage['stage'],stage['stage'])
    for label,source in [('base','/Applications/wanderer'),('candidate',str(w))]:
        stage_name=label+'-'+n
        cmd=stage['command'].copy()
        cmd[cmd.index('--path')+1]=source
        cmd[cmd.index('--log-file')+1]=str(p/(stage_name+'.engine.log'))
        cmd=[str('--report='+str(p/(stage_name+'.report.json'))) if arg.startswith('--report=') else arg for arg in cmd]
        commands.append(dict(stage=stage_name,command=cmd,exit=runs[stage_name]['exit']))
commands.append(dict(stage='b4-final',command=[engine,'--headless','--log-file',str(p/'b4-final.engine.log'),
    '--script','res://tests/actors/m4_05_playable_event_proof.gd','--','--report='+str(p/'b4-final.report.json')],exit=0,cwd=str(w)))
focus_errors={}
for cmd in commands:
    n=cmd['stage']
    errors=[line for line in (p/(n+'.log')).read_text().splitlines() if re.search('ERROR:',line)]
    if errors: focus_errors[n]=errors
assert set(focus_errors)<= {'candidate-lifecycle'}
assert len(focus_errors.get('candidate-lifecycle',[]))==3
base='9ae5df61a31083e5d55cba324f9ecd0189ca34b5'
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z']).decode().split('\0')
paths=sorted({x for x in paths if x and not x.endswith('.md') and '/evidence/' not in x})
tested={}
snapshot=p/'candidate94/snapshot'
for x in paths:
    f=w/x
    if not f.is_file():continue
    tested[x]=sha(f)
    if (snapshot/x).is_file() and x != 'tests/actors/m4_05_playable_event_proof.gd':
        assert tested[x]==sha(snapshot/x),x
write('tested-source-sha256.json',tested)
effects=read_report('base-effects')
write('results.json',{'canonical_sha':base,'godot_version':(p/'version.log').read_text().strip(),
    'godot_binary':engine,'godot_sha256':sha(engine),'fixtures':{'v1':effects['v1_sha256'],'v2':effects['v2_sha256']},
    'b4':{'status':'PASS','assertions':len(report['checks']),'requests':len(report['traces']),'streams':len(report['events'])},
    'inherited_suites':runs,'schema_audit':{'baseline_b3':1907,'candidate':1907,'identical_label_multiset':True,
        'original_1846_plus_61_source':'../b3/runtime/schema-count-audit.json'},
    'focused_commands':commands,'focused_engine_errors':focus_errors,'combat':combat,'legacy':{'cases':6,'frames':5892,'exact':True},
    'not_run':['GUI','keyboard','visual timing','performance §24.1','independent review']})
with zipfile.ZipFile(e/'logs-and-traces.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for f in sorted(p.iterdir()):
        if f.is_file() and f.suffix in ['.log','.json','.exit','.py']:
            z.write(f,f.name)
    z.write('/private/tmp/wanderer-b3-focused-final2/original-smoke.gd','original-smoke.gd')
    for n in combat:
        for f in sorted((p/n).iterdir()):
            if f.is_file():z.write(f,n+'/'+f.name)
write('archive-sha256.json',{'logs-and-traces.zip':sha(e/'logs-and-traces.zip')})
print('B4',len(report['checks']),len(report['traces']),len(report['events']), 'tested files',len(tested))
