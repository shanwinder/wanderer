import concurrent.futures, json, pathlib, subprocess
p=pathlib.Path('/private/tmp/wanderer-b4-verification')
godot='/Applications/Godot.app/Contents/MacOS/Godot'
common='npc-proof actor-proof ownership-proof party-foundation-proof party-turn-proof party-playable-proof presentation-proof autonomous-main-proof'.split()
full='main-cutover-proof guidance-data-proof guidance-decision-proof guidance-main-proof m4-data-proof m4-atomic-clock-proof m4-queue-foundation-proof m4-retreat-transaction-proof m4-outcome-summary-proof m4-autonomous-decision-proof'.split()
def run(name, cwd, args):
    cmd=['python3','tests/combat/verify.py','--godot',godot,'--output',str(p/name),*args]
    with (p/(name+'.log')).open('w') as log:
        code=subprocess.run(cmd,cwd=cwd,stdout=log,stderr=subprocess.STDOUT).returncode
    (p/(name+'.json')).write_text(json.dumps(dict(command=cmd,cwd=cwd,exit=code),indent=2))
    return code
if run('reference44','/private/tmp/wanderer-b3-reference44-source',['--'+x for x in common]): raise SystemExit(1)
args=['--'+x for x in common+full]+['--cutover-baseline',str(p/'reference44')]
with concurrent.futures.ThreadPoolExecutor() as pool:
    a=pool.submit(run,'canonical94','/Applications/wanderer',args)
    b=pool.submit(run,'candidate94','/private/tmp/wanderer-m4-05b-b4-events-restart',args)
    raise SystemExit(int(bool(a.result() or b.result())))
