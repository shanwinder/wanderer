import concurrent.futures, hashlib, json, pathlib, re, subprocess
p=pathlib.Path('/private/tmp/wanderer-b4-fix-verification')
binary='/Applications/Godot.app/Contents/MacOS/Godot'
base='/Applications/wanderer'
candidate='/private/tmp/wanderer-m4-05b-b4-events-restart'
smoke='/private/tmp/wanderer-b3-focused-final2/original-smoke.gd'
authority='res://tests/actors/m4_05_playable_authority_proof.gd'
def run(spec):
    name, cwd, args=spec
    args=[x.replace('@report',str(p/(name+'.report.json'))) for x in args]
    cmd=[binary,'--headless','--path',cwd,'--log-file',str(p/(name+'.engine.log')),*args]
    out=p/(name+'.log')
    with out.open('w') as log:
        status=subprocess.run(cmd,cwd=cwd,stdout=log,stderr=subprocess.STDOUT,timeout=900).returncode
    lines=out.read_text().splitlines()
    return dict(stage=name,command=cmd,exit=status,summary=lines[-1] if lines else '',engine_errors=[x for x in lines if re.search('ERROR:',x)])
def test(label, cwd, script, *flags):
    return (label,cwd,['--script',script,'--','--report=@report',*flags])
stages=[('version',candidate,['--version']),('import-candidate',candidate,['--editor','--import'])]
results=[run(s) for s in stages]
stages=[]
for label,cwd in [('candidate',candidate)]:
    stages += [test(label+'-smoke',cwd,smoke),test(label+'-expanded',cwd,authority),
      test(label+'-schema',cwd,authority,'--gate=D'),test(label+'-transactions',cwd,authority,'--gate=E'),
      test(label+'-effects',cwd,'res://tests/actors/m4_05_playable_effect_proof.gd'),
      test(label+'-lifecycle',cwd,'res://tests/actors/m4_05_playable_lifecycle_proof.gd')]
for name in ['playable_encounter','playable_rules','playable_input_adapter','playable_presentation_projection']:
    stages.append(('parse-'+name,candidate,['--check-only','--script','res://scripts/m4/'+name+'.gd']))
stages.append(test('b4-event',candidate,'res://tests/actors/m4_05_playable_event_proof.gd'))
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    for result in pool.map(run,stages):
        results.append(result)
        (p/'focused.json').write_text(json.dumps(dict(stages=results),indent=2))
        print(result['stage'],result['exit'],result['summary'],flush=True)
(p/'focused.json').write_text(json.dumps(dict(godot_sha256=hashlib.sha256(pathlib.Path(binary).read_bytes()).hexdigest(),stages=results),indent=2))
