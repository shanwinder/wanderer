import collections, hashlib, json, pathlib, subprocess, zipfile
w=pathlib.Path('/private/tmp/wanderer-m4-05b-b4-events-restart')
p=pathlib.Path('/private/tmp/wanderer-b4-fix-verification')
e=w/'tests/actors/evidence/m4-05b/b4/restart-regression-fix'
e.mkdir(exist_ok=True)
def dump(name,x):
 (e/name).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
def sha(x):return hashlib.sha256(x).hexdigest()
def counts(f):
 j=json.loads(f.read_text())
 return collections.Counter(c['label'] for c in j['checks'])
results=json.loads((p/'focused.json').read_text())
assert all(r['exit']==0 and not r['engine_errors'] for r in results['stages'])
assert all(json.loads(f.read_text()).get('status','PASS')=='PASS' for f in p.glob('*.report.json'))
audit={}
old=pathlib.Path('/private/tmp/wanderer-b4-verification')
for suite in ['smoke','expanded','schema','transactions','effects','lifecycle']:
 before=counts(old/('base-'+suite+'.report.json'))
 after=counts(p/('candidate-'+suite+'.report.json'))
 removed=before-after
 if suite=='effects':
  assert removed=={'RESTART M405_INVALID_PHASE preserves full root':7},removed
 elif suite!='lifecycle':assert not removed,removed
 else:assert removed=={'RESTART expected REJECTED actual REJECTED/M405_INVALID_PHASE':3},removed
 audit[suite]={'before_checks':sum(before.values()),'after_checks':sum(after.values()),'removed_labels':dict(removed),'added_labels':dict(after-before)}
dump('assertion-audit.json',audit)
dump('results.json',results)
manifest=json.loads((w/'tests/actors/evidence/m4-05b/b4/tested-source-sha256.json').read_text())
new={}
for file,oldhash in manifest.items():
 new[file]=sha((w/file).read_bytes())
 if file not in ['tests/actors/m4_05_playable_effect_proof.gd','tests/actors/m4_05_playable_lifecycle_proof.gd']:
  assert new[file]==oldhash,file
dump('tested-source-sha256.json',new)
with zipfile.ZipFile(e/'logs-and-reports.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(p.iterdir()):
  if f.is_file():z.write(f,f.name)
dump('archive-sha256.json',{'logs-and-reports.zip':sha((e/'logs-and-reports.zip').read_bytes())})
print(json.dumps(audit,indent=2))
