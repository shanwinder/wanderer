extends SceneTree

const Owner = preload("res://scripts/m4/playable_encounter.gd")
const Catalog = preload("res://scripts/m4/playable_fixture_catalog.gd")
const Rules = preload("res://scripts/m4/playable_rules.gd")

var factory := RefCounted.new()
var input := RefCounted.new()
var driver := RefCounted.new()
var presenter := RefCounted.new()
var owner: Owner
var sequence := 0
var failures: Array[String] = []
var trace: Array[Dictionary] = []
var scenario: String

func _initialize() -> void:
	_terminal_history_prefix()
	_commandless_history_prefix()
	var report := {"failures": failures, "trace": trace, "catalog_sha256": [
		Catalog.canonical(Catalog.content(1)).sha256_text(),
		Catalog.canonical(Catalog.content(2)).sha256_text()]}
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--report="):
			var file := FileAccess.open(arg.trim_prefix("--report="), FileAccess.WRITE)
			if file == null:
				failures.append("could not write report")
			else:
				file.store_string(JSON.stringify(report, "\t"))
	print("B3 FEASIBILITY PREFIX: %d transactions, %d failures" % [trace.size(), failures.size()])
	quit(0 if failures.is_empty() else 1)

func _check(value: bool, label: String) -> bool:
	if not value:
		failures.append(scenario + ": " + label)
		printerr("FAIL ", failures.back())
	return value

func _start(fixture: String) -> bool:
	scenario = fixture
	owner = Owner.new(factory, input, driver, presenter)
	var result := owner.bootstrap({"domain": "M4_PLAYABLE", "version": 1,
		"fixture_id": fixture, "fixture_version": 1}, factory)
	return _check(result.get("status") == "CREATED" and owner.replay_matches(), "bootstrap")

func _tx(op: String, payload: Dictionary, expected: String, issuer: String = "DRIVER") -> Dictionary:
	var view := owner.read_view()
	sequence += 1
	var request := {"domain": "M4_PLAYABLE", "version": 1, "identity": view.identity,
		"queue_id": view.queue_id, "request_id": ("ui/" if issuer == "INPUT" else "driver/") + str(sequence),
		"issuer": issuer, "operation": op, "payload": payload}
	var before := owner.snapshot()
	var response := owner.transact(request, input if issuer == "INPUT" else driver)
	var after := owner.snapshot()
	var replay_equal := owner.replay_matches()
	trace.append({"scenario": scenario, "request": request, "response": response,
		"root_equal": before == after, "replay_equal": replay_equal, "after": after})
	_check(response.get("reason") == "M405_" + expected, op + " expected " + expected)
	_check(replay_equal, op + " replay equality")
	if response.get("status") == "REJECTED":
		_check(before == after, op + " rejected whole-root equality")
	return response

func _terminal_history_prefix() -> void:
	if not _start("m405-demo/main"): return
	var command := {"actor_id": "player", "action": "ATTACK", "target_id": "enemy_a"}
	var accepted := _tx("COMMAND", command, "COMMAND_ACCEPTED", "INPUT")
	if not _check(accepted.get("view") != null and accepted.view.has_accepted_fresh_command
		and not accepted.view.command_ready, "accepted command freshness"): return
	var admitted := _tx("ADMIT", {}, "ROUND_ADMITTED")
	if not _check(admitted.get("status") == "APPLIED", "real admission"): return
	var q: Dictionary = owner.snapshot().queue
	var locked := _tx("PLAYER_LOCK", {"slot_id": q.opportunities[0].slot_id}, "ACTION_LOCKED")
	if not _check(locked.get("token") != null, "actual Player token"): return
	var impact := _tx("IMPACT", {"token": locked.token}, "EFFECT_APPLIED")
	_check(impact.get("effect") != null and impact.effect.hp_delta == -5 and impact.receipt == null,
		"actual HP 15 to 10, no impact receipt")
	_tx("COMPLETE", {"token": locked.token}, "ACTION_COMPLETED")
	for index in range(1, 6):
		if index < 4:
			locked = _tx("DECIDE_LOCK", {"observation": owner.read_observation()}, "ACTION_LOCKED")
		else:
			locked = _tx("ENEMY_LOCK", {"slot_id": q.opportunities[index].slot_id}, "ACTION_LOCKED")
		if not _check(locked.get("token") != null, "actual token for cancelled opportunity"): return
		_tx("CANCEL", {"token": locked.token}, "ACTION_CANCELLED")
	var drained := owner.snapshot()
	_check(drained.queue.phase == "DRAINED" and drained.receipts.size() == 1
		and drained.enemies[0].hp == 10 and drained.enemies[1].hp == 12
		and Rules.classify(drained).result == "ACTIVE", "drained active round with one real receipt")
	_tx("CLOSE_ROUND", {}, "INVALID_PHASE")

func _commandless_history_prefix() -> void:
	if not _start("m405-demo/player-down"): return
	_tx("COMMAND", {"actor_id": "player", "action": "DEFEND", "target_id": "player"},
		"COMMAND_LOCKED", "INPUT")
	var view := owner.read_view()
	var guide := {"schema_version": 1, "guidance_type": "NONE", "issuer_player_id": "player",
		"preferred_target_id": "", "encounter_id": view.identity.session, "generation": 1,
		"round_id": 1, "expected_guidance_revision": 0}
	_tx("GUIDANCE", {"request": guide}, "COMMAND_LOCKED", "INPUT")
	_tx("ADMIT", {}, "ROUND_ADMITTED")
	_tx("ADVANCE", {}, "SLOT_DISPOSED")
	var after := owner.snapshot()
	var disposition: Dictionary = after.queue.dispositions[0]
	_check(disposition.actor_id == "player" and disposition.kind == "UNAVAILABLE"
		and disposition.action_id == null and after.actions.is_empty() and after.receipts.is_empty()
		and after.command == null, "first opportunity disposed before any NPC action")
	var locked := _tx("DECIDE_LOCK", {"observation": owner.read_observation()}, "ACTION_LOCKED")
	if not _check(locked.get("token") != null and locked.token.kind == "RESCUE"
		and locked.token.target_id == "player" and locked.token.episode_id == after.party[0].episode.episode_id,
		"NPC1 selected RESCUE from real owner observation"): return
	_tx("IMPACT", {"token": locked.token}, "INVALID_PHASE")
