extends "res://tests/actors/m4_05_playable_lifecycle_proof.gd"
func _initialize() -> void:
	scenario = "diagnostic"
	var owner: RefCounted = boot()
	tx(owner, "GUIDANCE", {"request": guidance_request(owner, "ATTACK")}, "ACCEPTED")
	command(owner); admit(owner); finish(owner, lock(owner))
	var observed: Dictionary = owner.read_observation()
	var decision: Dictionary = Rules.Adapter.decide(observed)
	print("DECISION ", decision)
	print("VALID ", C.valid("Decision", decision))
	var req: Dictionary = request(owner, "DECIDE_LOCK", {"observation": observed})
	var result: Dictionary = Rules.step(owner.snapshot(), req)
	print("STEP ", result.response)
	if not result.root.is_empty():
		print("CANDIDATE ", Rules.candidate_valid(owner.snapshot(), req, result))
		print("ROOT ", Rules.root_valid(result.root))
	quit()
