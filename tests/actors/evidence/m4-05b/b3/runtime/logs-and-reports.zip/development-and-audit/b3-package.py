import json,hashlib,collections,subprocess,zipfile,shutil,platform
from pathlib import Path
root=Path('/private/tmp/wanderer-m4-05b-b3-runtime');e=root/'tests/actors/evidence/m4-05b/b3/runtime';e.mkdir(exist_ok=True)
focused=Path('/private/tmp/wanderer-b3-focused-final2');proof=json.loads((focused/'lifecycle.json').read_text());stages=json.loads((focused/'results.json').read_text())
assert all(x['passed'] for x in stages) and proof['status']=='PASS'
base=json.loads(Path('/private/tmp/b3-canonical-schema.json').read_text());candidate=json.loads((focused/'schema.json').read_text())
a=collections.Counter(c['label'] for c in base['checks']);b=collections.Counter(c['label'] for c in candidate['checks'])
assert not a-b and all(c['passed'] for c in base['checks']+candidate['checks'])
count_audit={'baseline_count':len(base['checks']),'candidate_count':len(candidate['checks']),'missing_original_labels':dict(a-b),'additional_labels':dict(b-a),'original_test_unchanged':True,'explanation':'The unchanged dynamic collector now sees real Decision/DecisionIdentity/Choice/DecisionReason/Relation/LegalEffect in View. All original 1,846 assertions remain; 61 additional assertions pass. Initial wrapper expected a fixed count and exited 1; its logs/results are preserved, without changing the original tests.'}
(e/'schema-count-audit.json').write_text(json.dumps(count_audit,indent=2)+'\n')
combat=[];legacy=[]
for name,sha in [('reference44','1728c5e678c5065278d1251d50449a8820eb5dae'),('canonical94','7f2e3807f18c91416c8380c5b3369711c65cdc5a'),('candidate94','7f2e3807f18c91416c8380c5b3369711c65cdc5a + tested source manifest')]:
 d=Path('/private/tmp/wanderer-b3-'+name+'-run');r=json.loads((d/'results.json').read_text());assert all(x['status']=='PASS' for x in r)
 expected=[x for x in r if x.get('errors')];assert len(expected)==1 and len(expected[0]['errors'])==5
 combat.append({'name':name,'source':sha,'output_directory':str(d),'stage_count':len(r),'passed_stages':len(r),'unexpected_errors':0,'expected_negative_errors':expected,'results':r})
 legacy.append(json.loads((d/'presentation-traces.json').read_text())['traces'])
assert legacy[0]==legacy[1]==legacy[2]
coverage={'status':'PASS','assertions':len(proof['checks']),'external_requests':len(proof['traces']),'scenario_count':8,'scenarios':{},'coverage_limits':proof['coverage_limits'],'evidence':'logs-and-reports.zip: focused-final2/lifecycle.json; complete journals, frozen/settled roots, requests/responses, root digests and assertion labels'}
for name in ['victory','guard_terminal','six_closes','last_party_down','rescue_retreat','guidance','failed_close','classifier']:
 checks=[c for c in proof['checks'] if c['scenario']==name]
 coverage['scenarios'][name]={'assertions':len(checks),'all_passed':all(c['passed'] for c in checks),'categories':dict(collections.Counter(c['category'] for c in checks))}
coverage['terminal_results']={}
for name in ['victory','guard_terminal','last_party_down']:
 frozen=proof['final_roots'][name+'-frozen'];settled=proof['final_roots'][name]
 coverage['terminal_results'][name]={'outcome':frozen['outcome']['result'],'freeze_revision':frozen['outcome']['freeze_revision'],'closed_rounds':settled['closed_rounds'],'impact_queue':frozen['queue']['phase'],'complete_queue':settled['queue']['phase'],'impact_receipts':len(frozen['receipts']),'completion_receipts':len(settled['receipts']),'frozen_outcome_unchanged':frozen['outcome']==settled['outcome']}
(e/'coverage.json').write_text(json.dumps(coverage,indent=2,ensure_ascii=False)+'\n')
manifest=json.loads((focused/'source-sha256.json').read_text());current={};ephemeral={}
for name,digest in manifest.items():
 p=root/name
 if not p.exists():
  assert name.endswith('.uid');ephemeral[name]=digest;continue
 assert hashlib.sha256(p.read_bytes()).hexdigest()==digest,name
 current[name]=digest
uid='tests/actors/m4_05_playable_lifecycle_proof.gd.uid'
assert (root/uid).read_bytes()==(focused/'snapshot'/uid).read_bytes()
current[uid]=hashlib.sha256((root/uid).read_bytes()).hexdigest()
(e/'tested-source-sha256.json').write_text(json.dumps(current,indent=2)+'\n')
protected=json.loads(Path('/private/tmp/b3-protected-sha256.json').read_text())
summary={'date':'2026-11-13','timezone':'Asia/Bangkok','status':'PASS — IMPLEMENTED CANDIDATE; INDEPENDENT REVIEW PENDING','base_commit':'7f2e3807f18c91416c8380c5b3369711c65cdc5a','branch':'codex/m4-05b-b3-runtime','worktree':str(root),'tested_source':'Exact contents in tested-source-sha256.json and tested-source.zip. Commit resolution follows after commit and is linked from the Draft PR.','godot_binary':'/Applications/Godot.app/Contents/MacOS/Godot','godot_version':'4.7.2.stable.official.ed1daf0bf','godot_sha256':hashlib.sha256(Path('/Applications/Godot.app/Contents/MacOS/Godot').read_bytes()).hexdigest(),'host':platform.platform(),'focused_stages':stages,'b1_schema_count_audit':'schema-count-audit.json','combat':combat,'legacy':{'cases':6,'frames':5892,'exact_equality':True},'coverage':'coverage.json','fixture_digests':['09f773cd96f7bb61bfd42226f1324b863a3eec484a684b88e85709bf5afeb28c','f797cf7d11e20a0070eec3de7f2bb776e70ff36c1b95afed6192079703e7077e'],'protected_file_count':len(protected),'not_run':['GUI','keyboard','visual/pacing','performance benchmarks','independent code/contract/evidence review'],'development_history':[{'stage':'first parse before fresh import','result':'class cache missing; import corrected; not final PASS evidence'},{'stage':'first lifecycle run','result':'interrupted after redundant schema allocation; exit130; retained log'},{'stage':'second lifecycle run','result':'1536 checks / 2 failures; exposed pre-existing v1 mapping hp vs current_hp; corrected only new-domain adapter'},{'stage':'focused Guidance repair','result':'494 checks PASS'},{'stage':'first final wrapper','result':'runtime proofs passed; wrapper exited1 because schema count was1907 rather than1846; full label-superset audit resolved; preserved unchanged'},{'stage':'final2','result':'19 stages PASS; B3 2486 assertions and627 requests; includes independent HP/clock expectations'}],'skills':[]}
for name in ['godot-gdscript','godot-gdscript-headless-testing']:
 p=Path('/Applications/wanderer/.agents/skills')/name/'SKILL.md'
 summary['skills'].append({'name':name,'source':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'worktree_installation':False,'usage':'Technical reference only; project checks used; no third-party helper executed or skill installed.'})
(e/'results.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
with zipfile.ZipFile(e/'logs-and-reports.zip','w',zipfile.ZIP_DEFLATED) as z:
 for label,d in [('focused-final2',focused),('focused-final1',Path('/private/tmp/wanderer-b3-focused-final'))]+[(name,Path('/private/tmp/wanderer-b3-'+name+'-run')) for name in ['reference44','canonical94','candidate94']]:
  for p in sorted(d.iterdir()):
   if p.is_file():z.write(p,label+'/'+p.name)
 for name in ['b3-first-parse.log','b3-import.engine.log','b3-proof-parse.log','b3-dev.engine.log','b3-dev2.engine.log','b3-dev2.json','b3-guidance-diag.gd','b3-guidance-diag.engine.log','b3-guidance-fixed.engine.log','b3-guidance-fixed.json','b3-canonical-schema.engine.log','b3-canonical-schema.json','b3-final-focused.py','b3-final-focused2.py','b3-protected-sha256.json']:
  p=Path('/private/tmp')/name
  if p.exists():z.write(p,'development-and-audit/'+name)
with zipfile.ZipFile(e/'tested-source.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in current:z.write(root/name,name)
 # Ephemeral UIDs were generated by import for old scripts that have no tracked UID.
 # They are preserved only as snapshot metadata, not unrelated source additions.
 for name in ephemeral:z.write(focused/'snapshot'/name,'import-generated/'+name)
archive={}
for name in ['logs-and-reports.zip','tested-source.zip']:
 p=e/name
 with zipfile.ZipFile(p) as z: entries={n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist()}
 archive[name]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size,'entries':entries}
(e/'archive-sha256.json').write_text(json.dumps(archive,indent=2)+'\n')
print('Packaged',len(current),'tested files;',len(protected),'protected files;',len(proof['checks']),'checks')
