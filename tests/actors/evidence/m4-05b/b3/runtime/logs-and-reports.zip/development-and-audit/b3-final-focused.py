import hashlib,json,os,re,shutil,subprocess,time,zipfile
from pathlib import Path
source=Path('/private/tmp/wanderer-m4-05b-b3-runtime')
out=Path('/private/tmp/wanderer-b3-focused-final');out.mkdir()
snapshot=out/'snapshot';snapshot.mkdir()
paths=subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard'],cwd=source).decode().split('\0')
manifest={}
for name in paths:
 if not name or '/evidence/' in name or name.startswith(('.agents/','.godot/','docs/')):continue
 p=source/name
 if not p.is_file():continue
 if p.suffix not in ['.gd','.uid','.tscn','.tres','.png','.svg','.godot','.import']:continue
 dest=snapshot/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
 manifest[name]=hashlib.sha256(p.read_bytes()).hexdigest()
(out/'source-sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
shutil.copy2('/private/tmp/b3-original-smoke.gd',out/'original-smoke.gd')
godot='/Applications/Godot.app/Contents/MacOS/Godot'
results=[]
def run(name,args,checks=None):
 cmd=[godot,'--headless','--path',str(snapshot),'--log-file',str(out/(name+'.engine.log'))]+args
 started=time.monotonic()
 try:
  proc=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=3600)
  log,code=proc.stdout,proc.returncode
 except subprocess.TimeoutExpired as e:
  log=e.stdout or b''
  if isinstance(log,bytes):log=log.decode(errors='replace')
  code=124
 (out/(name+'.log')).write_text(log);(out/(name+'.exit')).write_text(str(code)+'\n')
 errors=re.findall(r'^(?:SCRIPT ERROR|ERROR):.*$',log,re.M)
 report=out/(name+'.json');actual=None;status=None
 if report.exists():
  data=json.loads(report.read_text());actual=len(data.get('checks',[]));status=data.get('status')
 passed=code==0 and not errors and (checks is None or actual==checks) and (status is None or status=='PASS')
 results.append(dict(stage=name,command=cmd,exit_code=code,unexpected_errors=errors,expected_checks=checks,actual_checks=actual,status=status,passed=passed,elapsed_seconds=round(time.monotonic()-started,3)))
 (out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
 print(name,'PASS' if passed else 'FAIL',actual,flush=True)
 if not passed:print(log[-3500:],flush=True)
run('version',['--version'])
run('import',['--editor','--import'])
for name in sorted(manifest):
 if name.startswith('scripts/m4/playable_') and name.endswith('.gd') or name in ['tests/actors/m4_05_playable_authority_proof.gd','tests/actors/m4_05_playable_effect_proof.gd','tests/actors/m4_05_playable_lifecycle_proof.gd']:
  run('parse-'+Path(name).stem,['--check-only','--script','res://'+name])
run('original-smoke',['--script',str(out/'original-smoke.gd'),'--','--report='+str(out/'original-smoke.json')],86)
for name,gate,count in [('expanded','',97),('schema','D',1846),('transactions','E',354)]:
 run(name,['--script','res://tests/actors/m4_05_playable_authority_proof.gd','--','--report='+str(out/(name+'.json'))]+(['--gate='+gate] if gate else []),count)
run('effects',['--script','res://tests/actors/m4_05_playable_effect_proof.gd','--','--report='+str(out/'effects.json')],1010)
run('lifecycle',['--script','res://tests/actors/m4_05_playable_lifecycle_proof.gd','--','--report='+str(out/'lifecycle.json')])
raise SystemExit(0 if all(x['passed'] for x in results) else 1)
