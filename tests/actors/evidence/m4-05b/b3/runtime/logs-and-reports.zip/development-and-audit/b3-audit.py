import json,subprocess,hashlib,re,urllib.parse,collections,unicodedata
from pathlib import Path
r=Path('/private/tmp/wanderer-m4-05b-b3-runtime');e=r/'tests/actors/evidence/m4-05b/b3/runtime'
base='7f2e3807f18c91416c8380c5b3369711c65cdc5a'
allowed={'README.md','docs/README.md','tests/actors/README.md','scripts/m4/playable_contract.gd','scripts/m4/playable_decision_adapter.gd','scripts/m4/playable_effect_rules.gd','scripts/m4/playable_encounter.gd','scripts/m4/playable_rules.gd','scripts/m4/playable_guidance_adapter.gd','scripts/m4/playable_guidance_adapter.gd.uid','scripts/m4/playable_input_adapter.gd','scripts/m4/playable_input_adapter.gd.uid','tests/actors/m4_05_playable_lifecycle_proof.gd','tests/actors/m4_05_playable_lifecycle_proof.gd.uid'}
def git(*args):return subprocess.check_output(['git',*args],cwd=r).decode()
changed=set(git('diff','--name-only',base).splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
changed.add('tests/actors/evidence/m4-05b/b3/runtime/scope-audit.json')
unexpected=sorted(n for n in changed if n not in allowed and not n.startswith('tests/actors/evidence/m4-05b/b3/runtime/'))
protected=json.loads(Path('/private/tmp/b3-protected-sha256.json').read_text())
mismatch=[n for n,h in protected.items() if hashlib.sha256((r/n).read_bytes()).hexdigest()!=h]
scope={'base':base,'branch':git('branch','--show-current').strip(),'merge_base':git('merge-base','HEAD','visual-combat-test-1').strip(),'changed_files':sorted(changed),'unexpected_files':unexpected,'protected_file_count':len(protected),'protected_mismatches':mismatch,'protected_hashes':'logs-and-reports.zip/development-and-audit/b3-protected-sha256.json','skill_installation_files_changed':False,'current_worktrees':git('worktree','list','--porcelain'),'initial_main_checkout':'clean visual-combat-test-1 at required SHA; retained untouched','live_canonical_recheck':base,'markdown':{}}
(e/'scope-audit.json').write_text(json.dumps(scope,indent=2)+'\n')
files=['README.md','docs/README.md','tests/actors/README.md','tests/actors/evidence/m4-05b/b3/runtime/REPORT.md']
errors=[];links=0;anchors=0
for name in files:
 text=(r/name).read_text()
 for url in re.findall(r'\[[^\]]*\]\(([^\s)]+)\)',text):
  if re.match(r'^[a-zA-Z]+:',url):continue
  parsed=urllib.parse.urlsplit(url);dest=(r/name).parent/urllib.parse.unquote(parsed.path) if parsed.path else r/name
  links+=1
  if not dest.exists():errors.append([name,url,'missing file']);continue
  if parsed.fragment:
   anchors+=1
   if dest.suffix!='.md':continue
   desttext=dest.read_text();slugs=set(re.findall(r'id=["\']([^"\']+)',desttext));seen=collections.Counter()
   for title in re.findall(r'^#{1,6}\s+(.+)$',desttext,re.M):
    title=re.sub(r'\[([^\]]+)\]\([^)]+\)',r'\1',title)
    slug=''.join(c for c in title.lower() if c in '-_ ' or unicodedata.category(c)[0] in 'LMN').replace(' ','-')
    slugs.add(slug if seen[slug]==0 else slug+'-'+str(seen[slug]));seen[slug]+=1
   if urllib.parse.unquote(parsed.fragment) not in slugs:errors.append([name,url,'missing anchor'])
scope['markdown']={'files':files,'local_links':links,'fragments':anchors,'errors':errors}
scope['diff_check_exit']=subprocess.run(['git','diff','--check'],cwd=r).returncode
(e/'scope-audit.json').write_text(json.dumps(scope,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'changed_files':len(changed),'protected':len(protected),'unexpected':unexpected,'mismatches':mismatch,'markdown':scope['markdown']},ensure_ascii=False))
assert not unexpected and not mismatch and not errors and scope['diff_check_exit']==0
