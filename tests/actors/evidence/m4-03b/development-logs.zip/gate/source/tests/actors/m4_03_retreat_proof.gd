extends SceneTree

const Encounter = preload("res://scripts/m4/isolated_queue_outcome_encounter.gd")
const Adapter = preload("res://scripts/m4/m403_queue_adapter.gd")
var authority := RefCounted.new()
var cases: Array = []
var checks: int = 0
var failures: int = 0
var current: Dictionary = {}
var start_checks: int = 0
var start_failures: int = 0


func _initialize() -> void:
	call_deferred("_run")


func check(ok: bool, message: String) -> void:
	checks += 1
	current.assertions.append({"description": message, "passed": ok})
	if not ok:
		failures += 1
		print("FAIL: %s %s" % [current.get("id", "setup"), message])


func begin(description: String) -> void:
	start_checks = checks
	start_failures = failures
	current = {"id": "M403B-%02d" % (cases.size() + 1), "expected": description, "steps": [], "assertions": []}


func end() -> void:
	current.assertion_count = checks - start_checks
	current.failure_count = failures - start_failures
	current.actual = "PASS" if current.failure_count == 0 else "FAIL"
	cases.append(current)
	print("CASE %s: %s" % [current.id, current.actual])


func fixture() -> Dictionary:
	var actors: Array = []
	for id in ["p", "n1", "n2", "n3", "a", "b"]:
		var role: String = "PLAYER" if id == "p" else ("ENEMY" if id in ["a", "b"] else "NPC")
		actors.append({"definition": {"actor_id": id, "display_name": id, "role": role, "base_max_hp": 10},
			"state": {"current_hp": 10} if role == "ENEMY" else
				{"current_hp": 10, "life_state": "ALIVE", "participation": "PRESENT"}})
	return {"actors": actors, "round_plan": [
		{"round_id": 3, "actor_order": ["p", "n1", "n2", "n3", "a", "b"]},
		{"round_id": 4, "actor_order": ["p", "n1", "n2", "n3", "a", "b"]}]}


func state(f: Dictionary, id: String, life: String, hp: int, participation: String = "PRESENT") -> void:
	for row in f.actors:
		if row.definition.actor_id == id:
			row.state = {"current_hp": hp} if row.definition.role == "ENEMY" else \
				{"current_hp": hp, "life_state": life, "participation": participation}


func request(e) -> Dictionary:
	var s: Dictionary = e.snapshot()
	return {"version": 1, "session": s.session, "generation": s.generation,
		"expected_revision": s.revision, "queue_id": s.queue.get("queue_id", "")}


func reset_request(e, f: Dictionary) -> Dictionary:
	var r: Dictionary = request(e)
	r.fixture = f.duplicate(true)
	return r


func observe(e, method: String, input: Variant, cap: Variant, reason: String, status: String, no_delta: bool) -> Dictionary:
	var before: Dictionary = e.snapshot()
	var result: Dictionary = e.call(method, input, cap)
	var after: Dictionary = e.snapshot()
	check(result.reason_code == reason, "%s expected %s got %s" % [method, reason, result])
	check(result.status == status, "exact status " + status)
	if no_delta:
		check(after == before, "N-all: entire published root unchanged")
	else:
		check(after.revision == (0 if method == "restart" else before.revision + 1), "one publication revision")
		check(after.generation == before.generation + (1 if method == "restart" else 0), "generation boundary")
	current.steps.append({"method": method, "input": input.duplicate(true) if input is Dictionary else input,
		"capability": "owned" if cap is RefCounted and cap == authority else ("missing" if cap == null else "foreign"),
		"expected_reason": reason, "expected_status": status, "N_all": no_delta,
		"actual": result.duplicate(true), "before": before, "after": after})
	return result


func fresh(f: Dictionary = fixture()):
	var e = Encounter.new(authority)
	observe(e, "restart", reset_request(e, f), authority, "M403_RESTARTED", "APPLIED", false)
	return e


func advance(e, reason: String = "M403_SLOT_UNAVAILABLE", status: String = "APPLIED", no_delta: bool = false) -> Dictionary:
	return observe(e, "advance", request(e), authority, reason, status, no_delta)


func _compatibility() -> void:
	begin("N50-INT-01A pure structural revision independent of cursor; legal A skip revision")
	var f: Dictionary = fixture()
	state(f, "p", "DOWN", 0)
	state(f, "n1", "DOWN", 0)
	var e = fresh(f)
	advance(e)
	var before: Dictionary = e.snapshot()
	var c: Dictionary = before.duplicate(true)
	c.revision += 2
	check(Adapter.valid_queue(c), "structural revisions may include future authorized action publications")
	var skip: Dictionary = Adapter.unavailable_candidate(c)
	check(skip.queue.dispositions[skip.queue.opportunities[1].opportunity_id].observed_revision == 3,
		"historical observed revision is actual input revision, not index1")
	check(Adapter.valid_queue(skip), "interleaved global revision history valid structurally")
	check(e._publish(skip, before.revision) == "M403_INVALID_CANDIDATE", "synthetic history cannot publish")
	check(e.snapshot() == before, "synthetic diagnostic N-all")
	current.steps.append({"kind": "PURE_STRUCTURAL_NOT_ACTION", "input": c, "actual": skip,
		"before": before, "after": e.snapshot()})
	end()
	begin("N50-INT-01B historical unavailability independent of future restored eligibility, no reinsertion")
	e = fresh(f)
	advance(e)
	before = e.snapshot()
	c = before.duplicate(true)
	c.actors.p.state.current_hp = 1
	c.actors.p.state.life_state = "ALIVE"
	c.actors.p.state.eligible = true
	check(Adapter.valid_queue(c), "historical DOWN observation survives pure future ALIVE structural model")
	check(c.queue.cursor == 1 and c.queue.opportunities == before.queue.opportunities,
		"structural restoration cannot add/rewind opportunity")
	check(not Adapter.eligibility(c, "p").slot_eligible, "restored past actor has no opportunity")
	check(e._publish(c, before.revision) == "M403_INVALID_CANDIDATE", "no legal RESCUE producer in B; synthetic import denied")
	check(e.snapshot() == before, "pure diagnostic never mutates authority")
	current.steps.append({"kind": "PURE_STRUCTURAL_NOT_RESCUE", "input": c, "before": before, "after": e.snapshot()})
	end()
	for variant in range(7):
		begin("Forged historical disposition %s rejected structurally and N-all" % variant)
		e = fresh(f)
		before = e.snapshot()
		c = Adapter.unavailable_candidate(before)
		var d: Dictionary = c.queue.dispositions[c.queue.opportunities[0].opportunity_id]
		match variant:
			0: d.issuer_id = "foreign"
			1: d.observed_revision = 1
			2: d.observed_revision = -1
			3: d.observed_actor = before.actors.n2
			4: d.observed_actor.state.eligible = true
			5: d.actor_id = "n1"
			6: d.extra = true
		check(not Adapter.valid_queue(c), "forged structural history rejected")
		check(e._publish(c, before.revision) == "M403_INVALID_CANDIDATE", "exact publication rejects forged history")
		check(e.snapshot() == before, "full root N-all")
		current.steps.append({"kind": "INVALID_CANDIDATE", "input": c, "before": before, "after": e.snapshot()})
		end()


func _run() -> void:
	_compatibility()
	var report: Dictionary = {"suite": "M4-03B retreat transaction", "independent_cases": cases.size(),
		"assertion_checks": checks, "failures": failures, "per_frame_checks": 0, "cases": cases,
		"deferred": ["real actions not yet enabled", "RESCUE live interleaving", "M4-03C terminal/round integration"]}
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--report="):
			var file = FileAccess.open(arg.trim_prefix("--report="), FileAccess.WRITE)
			if file == null:
				quit(1)
				return
			file.store_string(JSON.stringify(report, "\t") + "\n")
	print("RESULT: %s checks, %s failures" % [checks, failures])
	quit(0 if failures == 0 else 1)
