from pathlib import Path
p=Path('docs/README.md');s=p.read_text()
s=s.replace('M4-01/M4-02 merged; M4-03A isolated candidate','M4-01/M4-02/M4-03A merged; M4-03B isolated candidate')
s=s.replace('**Design merged PR #49**; M4-03A implementation candidate ตาม current status','**Design merged PR #49**; M4-03A merged / M4-03B candidate ตาม current status')
new='''**งานปัจจุบัน — 8 November 2026 (Asia/Bangkok): M4-03B — Isolated RETREAT Transaction Implemented Candidate / Awaiting Independent Code & Evidence Review.** Owner attached an explicit B-only implementation task, then explicitly selected the opt-in subclass solution in this chat to preserve A's absent-B-API assertions. Canonical/local/fetched/live/merge-base `5cf53e0d145d3a518fcedd458ba2a892eb52cb1f`; [PR #50](https://github.com/shanwinder/wanderer/pull/50) squash merged with that SHA on7November2026; [independent review](https://github.com/shanwinder/wanderer/pull/50#pullrequestreview-5809782726) recorded A Code/Evidence PASS with future N50-INT-01 gate. PR50 branch absent locally/remotely, initial tree clean; no duplicate B branch/PR; #2/#17 remain unmerged/untouched. Branch `codex/m4-03b-isolated-retreat-transaction`. [Exact API/schema and Thai learning notes](../tests/actors/README.md#m4-03b--isolated-retreat-transaction); [reproducible commands, source SHA, all evidence and delivery-HEAD resolution](../tests/actors/evidence/m4-03b/run-record.json).

**Verified in this B task:** Godot `4.7.2.stable.official.ed1daf0bf`, tested `62cd64ae4f681a553e282881cac994d90f0d0d03`: **138 independent B cases /3,138 assertions /0 failures /0 per-frame checks**; fresh canonical **77/77**, committed candidate **82/82 stages PASS**. Original A unchanged **94 cases /1,165 assertions**, M401 **78/525**, M402 **55/1,188**; all21 inherited suite counts equal; Legacy **6 cases /5,892 frames identical**. All final exits0/unexpected errors0/timeouts0; five expected negative errors separate. Development FAIL retained separately. This is automated local evidence, not independent review or GUI acceptance.

**N50-INT-01:** A revision/cursor PASS through real Lock/Impact/Completion/Cancel + interleaved unavailable skips; B historical disposition PASS for **pure structural compatibility only**, with authentic observed snapshot/provenance, forged-history N-all and no reinsert; C original A regression PASS. One inherited root and `_publish` gate; pure adapter, owned exact15 token, serial lifecycle ledger, completion-only receipt and atomic retained-ID ALIVE/RETREATED effect. No public receipt/root import. A's public APIs remain unchanged; opt-in B facade is `m403_effect_candidates.gd` (documented filename adaptation, not a second owner).

**B boundaries / remaining gates:** last-active retreat is blocked **before lock/effect** with BOUNDARY_DEPENDENCY; pre-impact boundary after changed availability is diagnostic-only. SKIPPED/Completion under changed actor availability is pure bounded diagnostic, not legal damage/RESCUE interleaving. No Guard ledger exists in this aggregate; Guard-domain integration deferred, no production Guard access. **M403-08 NOT RUN / DEFERRED TO C** (no legal SEALED producer), **M403-10 DIAGNOSTIC-ONLY**, **M403-22 outcome DEFERRED TO C**. No classifier/frozen summary/terminal settlement, new effects, seal/close/abort/next round, NPC policy, UI or production integration. M402-06 BLOCKED / M402-24 PARTIAL unchanged. C must extend revision-event accounting for its own reviewed producers; B is serial, not a full future scheduler proof. **Stop at Draft PR for independent review; no merge/auto-merge/branch deletion or C/M4-04/M4-05.** Manual GUI/F5/F6/keyboard/visual NOT RUN.

'''
s=s.replace('## Current status and next roadmap\n\n','## Current status and next roadmap\n\n'+new)
s=s.replace('**งานปัจจุบัน — 7 November 2026', '**Historical A delivery checkpoint — 7 November 2026')
s=s.replace('**Verified in this task:** actual Godot', '**Inherited PR #50 delivery evidence (not B run):** actual Godot')
s=s.replace('**Design and remaining gates:** D07A', '**Historical A delivery gates (superseded only by current B authorization/status above):** D07A')
s=s.replace('งานปัจจุบันอนุญาต M4-03A เท่านั้น; B/C และ M4-04–05 ยังต้อง task/authorization แยก', 'งานปัจจุบันอนุญาต M4-03B เท่านั้น; C และ M4-04–05 ยังต้อง task/authorization แยก')
s=s.replace('งานปัจจุบันครอบคลุม M4-03A isolated foundation ตาม separate owner task; B/C ต้อง authorization แยก', 'M4-03A merged แล้ว; งานปัจจุบันครอบคลุม M4-03B ตาม separate owner task; C ต้อง authorization แยก')
s=s.replace('**M4-01/PR #47/PR #48/PR #49 merged แล้ว; งานนี้หยุดหลัง Draft PR M4-03A', '**M4-01/PR #47/PR #48/PR #49/PR #50 merged แล้ว; งานนี้หยุดหลัง Draft PR M4-03B')
s=s.replace('และไม่เริ่ม B/C, M4-04–05', 'และไม่เริ่ม C, M4-04–05')
s=s.replace('งานปัจจุบันเป็น M4-03A isolated implementation candidate ตามสถานะล่าสุดด้านบน', 'งานปัจจุบันเป็น M4-03B isolated implementation candidate ตามสถานะล่าสุดด้านบน')
p.write_text(s)
p=Path('README.md');s=p.read_text().replace('Current status (7 November 2026)', 'Current status (8 November 2026)')
a=s.index('- **M4-03A —');b=s.index('\n\nRead [AGENTS.md]',a)
s=s[:a]+'''- **M4-03A — Implemented / Merged:** [PR #50](https://github.com/shanwinder/wanderer/pull/50) squash merge `5cf53e0d145d3a518fcedd458ba2a892eb52cb1f`; recorded independent Code/Evidence Review PASS with N50-INT-01 future-integration gate.
- **M4-03B — Isolated RETREAT Transaction Implemented Candidate / Awaiting Independent Code & Evidence Review:** explicit B-only authorization and owner-selected opt-in subclass. N50 revision/cursor/history/A-regression gate PASS (history restoration structural only); real owned Lock/Impact/Completion/Cancel, retained IDs, no arbitrary receipt import. Fresh Godot4.7.2: **138 B cases /3,138 assertions**, canonical77/candidate82stages PASS; original A94/1,165, M40178/525, M40255/1,188; Legacy6cases/5,892frames identical. [Milestone authority and deferred boundaries](docs/README.md#current-status-and-next-roadmap), [API/evidence](tests/actors/README.md#m4-03b--isolated-retreat-transaction). No terminal/summary/round integration, production changes or manual visual acceptance; C requires a separate task.''' +s[b:]
p.write_text(s)
p=Path('tests/actors/README.md');s=p.read_text();s+='''

## M4-03B — Isolated RETREAT Transaction

**Implemented Candidate / Awaiting Independent Code & Evidence Review**,8November2026.
Canonical PR50 squash `5cf53e0d145d3a518fcedd458ba2a892eb52cb1f`; source tested
`62cd64ae4f681a553e282881cac994d90f0d0d03`. Owner explicitly authorized B only and
selected an opt-in subclass because the **unchanged A test asserts B APIs absent**.
[Milestone authority](../../docs/README.md#current-status-and-next-roadmap) owns status;
[run record](evidence/m4-03b/run-record.json) owns commands/engine/outputs/delivery resolution.

### Architecture, exact APIs and schemas

Instantiate [m403_effect_candidates.gd](../../scripts/m4/m403_effect_candidates.gd)
for B. Despite its allowed filename, this is a thin **opt-in Encounter facade**;
it inherits [isolated_queue_outcome_encounter.gd](../../scripts/m4/isolated_queue_outcome_encounter.gd),
including the single `_root`, Registry and `_publish` gate. It does not wrap another
live Encounter. A retains its original public APIs. All candidate calculations are
pure in [m403_queue_adapter.gd](../../scripts/m4/m403_queue_adapter.gd).

| API | Exact input / result |
|---|---|
| `lock_self_retreat(request,capability)` | Exact9: `version:int=1, session:int, generation:int, expected_revision:int, queue_id:String, slot_id:String, request_id:String, actor_id:String, kind:String=RETREAT`; no target. AUTHORIZED / M403_RETREAT_LOCKED + detached token |
| `impact(token)` | Exact owned token; APPLIED / M403_RETREATED or semantic SKIPPED / M403_ACTOR_UNAVAILABLE; revalidate current authority/state, not `lock_revision` equality |
| `complete(token)` | APPLIED/SKIPPED only; APPLIED / M403_ACTION_COMPLETED; one real receipt, cursor+1; actor need not still be eligible |
| `cancel(token)` | LOCKED only; APPLIED / M403_ACTION_CANCELLED; cursor+1, no effect, receipt or clock |
| inherited `advance/restart` | Original exact5/exact6 envelopes; WAIT_ACTION advance rejects ACTION_IN_PROGRESS; restart clears all action ledgers/active token |

Exact15 immutable token fields:
`version:int,session:int,generation:int,round_id:int,queue_id:String,slot_id:String,
action_id:int,actor_id:String,kind:String,target_id:String,lock_revision:int,
authorization_id:int,window_id:String,request_id:String,episode_id:String`.
Version1/kindRETREAT/target=self/episode empty. Action/auth serials are issuer-owned
`authorizations.size()+1`, generation-bound; failed lock/publication consumes nothing.
Window=`slot_id + /retreat`. Entire `slot_` and `m403/` namespaces reserved, including
future slots/rounds. Request reuse rejects before allocation; owned full equality,
phase, current opportunity and consumption are checked before effect.

Root exact fields remain unchanged. Authorizations are keyed by integer action ID;
exact grant row=`token,phase,impact_reason,impact_revision,disposed_revision`.
Initial revisions−1 mean absent; impact/disposal revisions record **post-publication**
revision. Active operation is null or the owned action ID. Exact completion receipt:
`action_id:int,authorization_id:int,slot_id:String,actor_id:String,queue_id:String,
completed_revision:int,impact_reason:String`. Only COMPLETE creates it; no import API.
Receipt identity/result/revision must equal the corresponding completed grant.

UNAVAILABLE disposition keeps A's four fields and adds two:
`slot_id:String,actor_id:String,kind:String=UNAVAILABLE,observed_revision:int,
issuer_id:String=M403_ISOLATED_QUEUE,observed_actor:Dictionary`.
Observed actor is the exact detached Registry row (`definition,state,membership`),
validated using original factories; immutable definition/membership match current
roster, but historical state need not match live eligibility. `observed_revision`
is the actual **pre-publication** revision. COMPLETED/CANCELLED dispositions use
`slot_id,actor_id,kind,observed_revision,issuer_id,action_id:int`, without an observed
actor copy. They must match an owned grant/disposal revision. No old live root/import
compatibility is promised: restart constructs the new schema; historical evidence
stays unchanged. Original A scenario behavior/assertions/counts are retained.

### N50-INT-01 and lifecycle accounting

Revision counts every authorized publication; cursor counts dispositions. Lock and
Impact leave cursor unchanged; Complete, Cancel and unavailable Skip advance once.
Queue phases: READY (current opportunity, not automatic action admission), WAIT_ACTION
(owned pending action), DRAINED (finite queue consumed; no round close). Action phases:
NONE→LOCKED→APPLIED→COMPLETED, LOCKED→CANCELLED, LOCKED→SKIPPED→COMPLETED.

Whole-root validation reconstructs the exact receipt set, one active grant, unique
slots/requests, every historical disposition, and a gap-free, duplicate-free set of
revision events. B's serial lifecycle has lock at L+1, impact L+2 and completion L+3
(or cancel L+2); no legal concurrent producer exists here. C must extend this event
accounting when adding reviewed producers, rather than claiming B supports them now.
Every publication compares the **whole candidate** to the legal pure transition from
current authority. Historical plausible-but-forged observations may pass structural
checks but cannot be published. No validator disabled and no fake receipts.

- **N50-INT-01A PASS:** real publications/interleaved skips (B10–11), actual revision
  differs from cursor/index; stale/duplicate/forged requests reject N-all.
- **N50-INT-01B PASS — structural scope:** B02 proves previously disposed Player can
  be ALIVE in a pure future model without slot reinsertion; forged history rejected.
  No legal aggregate RESCUE producer; **M403-16 end-to-end not claimed**.
- **N50-INT-01C PASS:** original A source/assertions unchanged,94cases/1,165assertions.
  Preliminary pre-action gate is archived separately with its source snapshot.

### Atomicity, rejection and boundaries

Request precedence: exact types/shape/version/kind → session/generation → capability
→ duplicate request → phase/active/queue/current slot → expected revision → reserved
namespace → Party/actionability → last-active dependency → candidate validation.
Token precedence: shape/types/version → session/generation → full owned equality
→ duplicate/cancelled accounting → phase/current queue/slot → legal action phase
→ domain revalidation → current revision/candidate gate. Cancel replay is
DUPLICATE_OPERATION; impact/complete of cancelled action is ACTION_CANCELLED.
Lock_revision remains immutable audit. Rejection is **N-all**, including counters,
grants, receipts and root revision. Successful Lock/Complete/Cancel are N-effect;
Impact changes only self participation and derived eligibility, plus action accounting.
All unrelated actors, HP/maxHP/IDs/roster/round/clock/outcome/summary remain unchanged.

B has **no Guard ledger or production Guard field**. Exact root/actor schemas admit
no stale guard authority in this scope; production Guard is untouched. Guard-domain
release integration is deferred, not marked verified. Last-active Party retreat
rejects BOUNDARY_DEPENDENCY before lock/effect; changed availability before impact is
only a detached observation diagnostic (no legal live producer). Legal pending token
can still cancel; no partial retreat or encounter outcome is invented.

### Fresh verification and coverage limits

Engine `/Applications/Godot.app/Contents/MacOS/Godot`,
`4.7.2.stable.official.ed1daf0bf`. **138 independent cases /3,138 assertions /0 failures**,
zero per-frame checks. Fresh canonical77/candidate82stages PASS; all exits0, no
unexpected errors/timeouts; five expected negative errors separate. A94/1,165,
M40178/525, M40255/1,188; all21 inherited suite counts identical. Legacy6cases/
5,892frames identical to fresh canonical and the provenanced inherited pre-cutover
reference. Failed development run retained (a no-op fault test, corrected without
changing runtime constants or inherited tests). GUI/F5/F6/keyboard/visual NOT RUN.

| M403 rows | Actual scope |
|---|---|
|01–07,09,40,43|FULLY PROVEN in B's isolated transaction domain; actual API lifecycle/replays/identity|
|08|NOT RUN / DEFERRED TO C; no legal SEALED producer, no fake sealed fixture|
|10|DIAGNOSTIC-ONLY / pure bounded candidate revalidation and completion; no legal mid-action damage producer|
|22|B rejection boundary proven; terminal outcome/freeze/settlement DEFERRED TO C|
|47–48|FULLY PROVEN for automated preservation/regression in this candidate; no manual/production adoption claim|

[Coverage and case mapping](evidence/m4-03b/coverage.json),
[every input/before-after/assertion](evidence/m4-03b/m4-03b-scenarios.json),
[compatibility gate](evidence/m4-03b/compatibility-gate.json),
[contract self-audit](evidence/m4-03b/review-checks.json),
[source hashes](evidence/m4-03b/source-comparison.json),
[Legacy](evidence/m4-03b/trace-comparison.json),
[raw logs/development history](evidence/m4-03b/run-record.json).
No terminal classifier/summary/settlement, new RESCUE/damage/HELP producers,
round seal/close/abort/next-round, autonomous policy, Guidance/UI or production changes.
SKIPPED Restart not executable through a legal producer; SEALED Abort/Restart deferred.
M402-06 remains BLOCKED / M402-24 PARTIAL. No C/M4-04/M4-05 work started.

### บทเรียนสั้น ๆ

Revision เปรียบเหมือนเลขรายการบันทึกทุกครั้งที่ระบบเผยแพร่ข้อมูล ส่วน Cursor คือ
ตำแหน่งสิทธิ์เล่นที่ยังไม่จบ จึงต้องแยกกัน: Lock จองสิทธิ์, Impact ให้ผลจริง,
Completion ปิดสิทธิ์, Cancel ใช้สิทธิ์ไปโดยไม่ให้ผล การข้าม Player ตอน DOWN เป็น
ประวัติว่า “ตอนนั้นทำไม่ได้” ไม่ใช่คำสั่งว่าต้อง DOWN ตลอดไป การฟื้นในอนาคตจึงต้อง
รักษาประวัติเดิมและไม่คืน slot ส่วน receipt ต้องมาจาก completion จริงเท่านั้น.
''';p.write_text(s)
p=Path('tests/combat/README.md');s=p.read_text();s+='''

## Optional M4-03B isolated RETREAT transaction proof

Add `--m4-retreat-transaction-proof` for four parse stages plus the focused B suite.
Uses the owner-selected opt-in subclass; A's unchanged absent-B-API assertions still
run through `--m4-queue-foundation-proof`. B report validation is separate/additive;
existing runner lines/gates remain unchanged. Exact JSON fields, unique sequential
case IDs, actual assertion booleans/count sum, stdout summary and CASE lines must agree.

Fresh8November2026 on source `62cd64ae4f681a553e282881cac994d90f0d0d03`:
Godot4.7.2, B138cases/3,138assertions, canonical77/candidate82stages PASS;
A94/1,165, M40178/525, M40255/1,188, Legacy6cases/5,892frames identical.
Unexpected errors/timeouts0, all exits0; negative exactly5 expected errors separate.
[Exact API/schema/limits](../actors/README.md#m4-03b--isolated-retreat-transaction),
[durable run record and full commands](../actors/evidence/m4-03b/run-record.json).

```sh
python3 tests/combat/verify.py --godot /Applications/Godot.app/Contents/MacOS/Godot --output /tmp/wanderer-m403b-final-20261108 --npc-proof --actor-proof --ownership-proof --party-foundation-proof --party-turn-proof --party-playable-proof --presentation-proof --autonomous-main-proof --main-cutover-proof --guidance-data-proof --guidance-decision-proof --guidance-main-proof --m4-data-proof --m4-atomic-clock-proof --m4-queue-foundation-proof --m4-retreat-transaction-proof --cutover-baseline /tmp/wanderer-m3a04-reference-20261105-2
```

Choose a fresh output path; the reference path above is inherited pre-cutover evidence,
not the77-stage canonical run. [Reference provenance](../actors/evidence/m4-03b/reference-provenance.json)
checks its44 results against durable M401 evidence and source against its own commit.
No new pre-cutover reference run claimed. SKIPPED interleaving is diagnostic-only;
SEALED/terminal/last-active outcome deferred to C. Guard integration/manual visual
acceptance NOT RUN. Stop at Draft PR; no merge/auto-merge or next milestone.
''';p.write_text(s)
