from pathlib import Path
import copy,hashlib,json,re,subprocess,tempfile,unicodedata,zipfile
from urllib.parse import unquote
ROOT=Path('/Applications/wanderer');DEST=ROOT/'tests/actors/evidence/m4-03b';BASE='5cf53e0d145d3a518fcedd458ba2a892eb52cb1f';TESTED='c4a7c488726983e0d29fb3b085e34f5d855895cb'
errors=[]
def check(ok,msg):
 if not ok:errors.append(msg)
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT)
def read(n):return json.loads((DEST/n).read_text())
allowed={'README.md','docs/README.md','tests/actors/README.md','tests/combat/README.md','tests/combat/verify.py','scripts/m4/m403_queue_adapter.gd','scripts/m4/isolated_queue_outcome_encounter.gd','scripts/m4/m403_effect_candidates.gd','scripts/m4/m403_effect_candidates.gd.uid','tests/actors/m4_03_retreat_proof.gd','tests/actors/m4_03_retreat_proof.gd.uid'}
changed=set(git('diff',BASE,'--name-only').decode().splitlines())|set(git('ls-files','--others','--exclude-standard').decode().splitlines())
check(all(n in allowed or n.startswith('tests/actors/evidence/m4-03b/') for n in changed),'changed-file scope')
protected=[]
for n in git('ls-tree','-r','--name-only',BASE).decode().splitlines():
 if n not in allowed:
  check((ROOT/n).read_bytes()==git('show',BASE+':'+n),'protected blob changed '+n);protected.append(n)
manifest=read('source-sha256.json')
for n,h in manifest.items():check(hashlib.sha256((ROOT/n).read_bytes()).hexdigest()==h==hashlib.sha256(git('show',TESTED+':'+n)).hexdigest(),'tested source mismatch '+n)
diff=git('diff',BASE,'--','tests/combat/verify.py').decode();check(not any(x.startswith('-') and not x.startswith('---') for x in diff.splitlines()),'runner removed existing line')
ns={'__name__':'m403b_review_import'};exec(compile((ROOT/'tests/combat/verify.py').read_text(),'verify.py','exec'),ns)
validator=ns['validate_m403b_report'];report=read('m4-03b-scenarios.json');log=Path('/tmp/wanderer-r51-final-20261108/m4-retreat-transaction-proof.log').read_text();variants=[]
with tempfile.TemporaryDirectory(prefix='m403b-report-audit-') as tmp:
 p=Path(tmp)/'report.json';p.write_text(json.dumps(report));check(validator(p,log),'actual report invalid')
 for name,mutate in [('bool independent count',lambda r:r.update(independent_cases=True)),('fraction assertion count',lambda r:r.update(assertion_checks=3339.0)),('missing case',lambda r:r['cases'].pop()),('duplicate ID',lambda r:r['cases'][1].update(id=r['cases'][0]['id'])),('case FAIL',lambda r:r['cases'][0].update(actual='FAIL')),('case SKIP',lambda r:r['cases'][0].update(actual='SKIP')),('missing assertion',lambda r:r['cases'][0]['assertions'].pop()),('false boolean',lambda r:r['cases'][0]['assertions'][0].update(passed=False)),('integer masquerades boolean',lambda r:r['cases'][0]['assertions'][0].update(passed=1)),('zero case count',lambda r:r['cases'][0].update(assertion_count=0)),('extra root field',lambda r:r.update(extra=True)),('nonzero failures',lambda r:r.update(failures=1)),('nonzero perframe',lambda r:r.update(per_frame_checks=1))]:
  r=copy.deepcopy(report);mutate(r);p.write_text(json.dumps(r));ok=not validator(p,log);check(ok,'validator accepted '+name);variants.append({'case':name,'actual':'PASS' if ok else 'FAIL'})
 for name,s in [('duplicate JSON key','{"suite":"a","suite":"b"}'),('NaN','{"value":NaN}'),('Infinity','{"value":Infinity}'),('malformed JSON','{')]:
  p.write_text(s);ok=not validator(p,log);check(ok,'parser accepted '+name);variants.append({'case':name,'actual':'PASS' if ok else 'FAIL'})
 p.write_text(json.dumps(report))
 for name,s in [('missing stdout',''),('wrong stdout total',log.replace('3339 checks','3338 checks')),('duplicate stdout summary',log+'RESULT: 3339 checks, 0 failures\n')]:
  ok=not validator(p,s);check(ok,'validator accepted '+name);variants.append({'case':name,'actual':'PASS' if ok else 'FAIL'})
check(len({c['id'] for c in report['cases']})==len(report['cases']),'case IDs duplicate')
for c in report['cases']:
 check(bool(c['steps']),c['id']+' missing input/before/after')
 check(all(type(a['passed']) is bool and a['passed'] for a in c['assertions']),c['id']+' invalid actual assertions')
 check(all('input' in s and 'before' in s and 'after' in s for s in c['steps']),c['id']+' missing input/full roots')
# Github-compatible local Markdown link/fragment audit across the repository guides.
def slug(v):
 v=re.sub(r'<[^>]*>','',v).lower().replace('`','')
 return ''.join(c for c in v if c.isspace() or c in '-_' or unicodedata.category(c)[0] in 'LNM').replace(' ','-')
mds=sorted(ROOT.glob('*.md'))+sorted((ROOT/'docs').glob('*.md'))+sorted((ROOT/'tests').glob('*/README.md'));anchors={}
for p in mds:
 names=set(re.findall(r'<a\s+(?:id|name)="([^"]+)"',p.read_text()));seen={}
 for h in re.findall(r'^#{1,6}\s+(.+?)\s*#*$',p.read_text(),re.M):
  n=slug(h);suffix=seen.get(n,0);names.add(n+(f'-{suffix}' if suffix else ''));seen[n]=suffix+1
 anchors[p.resolve()]=names
links=fragments=0
for p in mds:
 for v in re.findall(r'\[[^\]]*\]\(([^)]+)\)',p.read_text()):
  if '://' in v or v.startswith(('mailto:','data:')):continue
  v=v.split(' "',1)[0].strip('<>');file,_,fragment=v.partition('#');target=(p.parent/unquote(file)).resolve() if file else p.resolve();links+=1
  check(target.exists(),f'broken link {p.relative_to(ROOT)} -> {v}')
  if fragment and target.suffix=='.md':fragments+=1;check(unquote(fragment) in anchors.get(target,set()),f'broken fragment {p.relative_to(ROOT)} -> {v}')
zips=[]
for p in DEST.glob('*.zip'):
 with zipfile.ZipFile(p) as z:check(z.testzip() is None,'bad ZIP '+p.name);zips.append({'path':p.name,'entries':len(z.namelist()),'actual':'PASS'})
for n in ['final-results.json','canonical-results.json']:
 rows=read(n);check(all(r['status']=='PASS' and r['exit_code']==0 and not r['timed_out'] for r in rows),'failed runtime '+n)
 check(all(len(r['errors'])==(5 if r['step']=='invalid-actions' else 0) for r in rows),'unexpected engine errors '+n)
check(subprocess.run(['git','diff','--check'],cwd=ROOT,capture_output=True).returncode==0,'git diff --check')
for n in ['fac99aa96c08b3e53a9d8db74a0025b4153503bd','c162d63385ca8d6dd03a6b5cc5c0dbce2afda694']:check(subprocess.run(['git','merge-base','--is-ancestor',n,BASE],cwd=ROOT).returncode==1,'unmerged proposal became ancestor')
check(git('rev-list','--parents','-n','1',BASE).decode().split()==[BASE,'67d68bb1f78fa8efedcb719079a4487c531c49d4'],'PR50 squash parent')
reviewed='f8dd844a80bd0a7cfb013fcacff4acf21eb0af45'
fix_allowed={'README.md','docs/README.md','tests/actors/README.md','tests/combat/README.md','scripts/m4/m403_queue_adapter.gd','scripts/m4/isolated_queue_outcome_encounter.gd','tests/actors/m4_03_retreat_proof.gd'}
fix_changed=set(git('diff',reviewed,'--name-only').decode().splitlines())|set(git('ls-files','--others','--exclude-standard').decode().splitlines())
check(all(n in fix_allowed or n.startswith('tests/actors/evidence/m4-03b/') for n in fix_changed),'R51 focused file scope')
with zipfile.ZipFile(DEST/'pre-r51-evidence.zip') as z:
 old=git('ls-tree','-r','--name-only',reviewed,'--','tests/actors/evidence/m4-03b').decode().splitlines()
 check(len(z.namelist())==len(old)==21,'pre-fix archive count')
 for n in old:check(z.read(str(Path(n).relative_to('tests/actors/evidence/m4-03b')))==git('show',reviewed+':'+n),'pre-fix archive mismatch '+n)
result={'actual':'PASS' if not errors else 'FAIL','errors':errors,'changed_file_scope':sorted(changed),'tested_source_hashes_verified':len(manifest),'preexisting_unchanged_blobs_outside_allowed':len(protected),'Markdown_files':len(mds),'local_links':links,'fragments':fragments,'optional_report_adversarial_audit':variants,'existing_runner_lines_removed':False,'archive_integrity':zips,'contract_self_audit':read('contract-audit.json'),'independent_review':'PENDING; self-audit is not independent acceptance','not_run':read('run-record.json')['not_run'],'historical_pre_R51_packaging_failure_history':[{'command':'python3 /tmp/wanderer_m403b_package.py (first attempt)','actual':'FAIL KeyError assertion_checks: original M401 report uses checks; packaging field mapping corrected; no runtime/source/test change'}]}
result['R51-01']='FIX CANDIDATE / Awaiting independent follow-up review'
result['changed_files_from_reviewed_head']=sorted(fix_changed)
result['pre_fix_evidence_payloads_exactly_preserved']=21
result['current_development_history']='r51-01.json'
(DEST/'review-checks.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k in ['actual','errors','tested_source_hashes_verified','preexisting_unchanged_blobs_outside_allowed','Markdown_files','local_links','fragments']},indent=2))
if errors:raise SystemExit(1)
