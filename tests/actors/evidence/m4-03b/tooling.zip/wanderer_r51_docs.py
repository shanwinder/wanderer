from pathlib import Path
old='62cd64ae4f681a553e282881cac994d90f0d0d03';new='c4a7c488726983e0d29fb3b085e34f5d855895cb'
for name in ['README.md','docs/README.md','tests/actors/README.md','tests/combat/README.md']:
 p=Path(name);s=p.read_text().replace(old,new).replace('138 B cases /3,138 assertions','150 B cases /3,339 assertions').replace('138 independent B cases /3,138 assertions','150 independent B cases /3,339 assertions').replace('138 independent cases /3,138 assertions','150 independent cases /3,339 assertions').replace('B138cases/3,138assertions','B150cases/3,339assertions').replace('/tmp/wanderer-m403b-final-20261108','/tmp/wanderer-r51-final-20261108')
 if name=='README.md':
  s=s.replace('explicit B-only authorization and owner-selected opt-in subclass. N50','R51-01 fix candidate: new RETREAT requires **Active Party >1 AND Active Enemy >0**, rechecked at impact/publication; same Draft [PR #51](https://github.com/shanwinder/wanderer/pull/51), awaiting independent follow-up review. Explicit B-only authorization and owner-selected opt-in subclass. N50')
 if name=='docs/README.md':
  s=s.replace('**Verified in this B task:**','**R51-01 fix candidate / Awaiting Independent Follow-up Review — same Draft PR #51:** [Independent finding](https://github.com/shanwinder/wanderer/pull/51#pullrequestreview-5814945108) found that the original P>1-only gate admitted E=0 victory-boundary fixtures. Owner authorized this narrow correction on8November2026. New Lock now requires **P>1 AND E>0** after earlier protocol/domain gates; impact and the authoritative publication gate revalidate Enemy availability. E=0 rejects BOUNDARY_DEPENDENCY/N-all without a classifier. Existing owned Complete/Cancel are unchanged. The old all-Enemy-HP0 successful cancel fixture is replaced with E>0 cancel/skip accounting that stops at the living Enemy, without fake actions or receipts. [R51-01 coverage, red reproduction, exact sources and evidence](../tests/actors/evidence/m4-03b/r51-01.json). Reviewed HEAD `f8dd844a80bd0a7cfb013fcacff4acf21eb0af45`; historical pre-fix138/3,138 evidence retained in `pre-r51-evidence.zip` inside the B evidence folder; it is not a post-fix result.\n\n**Fresh verification after R51-01:**')
  s=s.replace('**B boundaries / remaining gates:** last-active retreat is blocked','**B boundaries / remaining gates:** zero-active-Enemy and last-active-Party retreat are blocked')
 if name=='tests/actors/README.md':
  s=s.replace('namespace → Party/actionability → last-active dependency → candidate validation.','namespace → Party/actionability → P>1 AND E>0 boundary dependency → candidate validation.')
  s=s.replace('Last-active Party retreat\nrejects BOUNDARY_DEPENDENCY before lock/effect;', 'Zero-active-Enemy and last-active-Party retreat\nreject BOUNDARY_DEPENDENCY before lock/effect;')
  s=s.replace('zero per-frame checks. Fresh canonical77/candidate82stages PASS;', 'zero per-frame checks. Fresh R51-01 canonical77/candidate82stages PASS;')
  s+='''

### R51-01 — Nonterminal RETREAT admission fix candidate

[Independent finding](https://github.com/shanwinder/wanderer/pull/51#pullrequestreview-5814945108)
on reviewed HEAD `f8dd844a80bd0a7cfb013fcacff4acf21eb0af45`: P>1 alone admitted
all-Enemy-HP0 fixtures, which require D10-A's VICTORY boundary. B does not implement
that classifier; new Lock must require **Active Party >1 AND Active Enemy >0**.
`active_enemies(view)` derives availability from authoritative initial Enemy IDs and
validated Registry rows (existing HP/can_act only; no Enemy lifecycle or mirror).

Public Lock preserves schema/session/generation/capability/duplicate/phase/queue/slot/
revision/reserved/domain precedence, then returns REJECTED/BOUNDARY_DEPENDENCY/N-all
for either boundary. Impact authenticates the owned token first, then blocks E=0;
when the actor remains actionable, P≤1 still blocks. The authoritative transition/
publication gate repeats these checks before building/publishing an effect. Existing
Complete/Cancel admission does not inspect this new boundary and remains unchanged.

B16 now cancels Party slots with Enemy A0/Enemy B10, skips A once, then returns B READY
without consumption; it no longer claims that actions may drain a terminal E=0 seed.
New **B139–150** cover repeated zero-Enemy Lock N-all, no grants/receipts/counters,
precedence variants, publication-gate refusal, restored legal nonterminal Lock/Impact/
Complete and bounded zero-Enemy pre-impact/settlement observations. The original
last-active tests remain. **Changing Enemy availability mid-action is diagnostic-only**;
no damage producer or fake terminal result is introduced.

[Current R51-01 evidence](evidence/m4-03b/r51-01.json) records150cases/3,339assertions,
reviewed→tested→delivery attribution and red/green history. Initial development harness
had a duplicate-local parse error (engine exit0 correctly failed the runner); corrected
harness against the reviewed runtime reproduced18failed assertions in150cases. Fixed
source passes; neither failed run is relabelled PASS. [Pre-fix evidence archive](evidence/m4-03b/pre-r51-evidence.zip)
preserves original138/3,138 records and logs exactly. Existing older-milestone evidence
is unchanged. **R51-01 awaits independent follow-up review**, not owner merge approval.
'''
 if name=='tests/combat/README.md':
  s+='''

R51-01 refresh uses the same Draft PR #51 and the actual post-fix source above.
RETREAT Lock/Impact now require a nonterminal Enemy availability boundary; the B
count is **150/3,339**, not the old138/3,138. [Red/green evidence and exact commands](../actors/evidence/m4-03b/r51-01.json)
retain both the initial harness parse failure and the genuine old-runtime reproduction.
Original A94/1,165 and all prior M4/production assertions remain unchanged. Completion/
Cancel are not subject to the new admission gate. No terminal classifier or production
integration; await independent follow-up review.
'''
 p.write_text(s)
