import copy
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tempfile
import unicodedata
from urllib.parse import unquote
import zipfile

ROOT = Path('/Applications/wanderer')
DEST = ROOT / 'tests/actors/evidence/m4-03a'
BASE = '67d68bb1f78fa8efedcb719079a4487c531c49d4'
TESTED = 'ad0e95ced3a7f52651d4dc671ef64634d3d148f9'
errors = []

def check(ok, description):
    if not ok:
        errors.append(description)

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)

def read(name):
    return json.loads((DEST / name).read_text())

def sha(value):
    return hashlib.sha256(value).hexdigest()

allowed = {'README.md', 'docs/README.md', 'tests/actors/README.md', 'tests/combat/README.md', 'tests/combat/verify.py',
           'scripts/m4/m403_queue_adapter.gd', 'scripts/m4/m403_queue_adapter.gd.uid',
           'scripts/m4/isolated_queue_outcome_encounter.gd', 'scripts/m4/isolated_queue_outcome_encounter.gd.uid',
           'tests/actors/m4_03_queue_foundation_proof.gd', 'tests/actors/m4_03_queue_foundation_proof.gd.uid'}
changed = set(git('diff', BASE, '--name-only').decode().splitlines())
changed.update(git('ls-files', '--others', '--exclude-standard').decode().splitlines())
check(all(n in allowed or n.startswith('tests/actors/evidence/m4-03a/') for n in changed), 'unauthorized changed file')
protected = []
for n in git('ls-tree', '-r', '--name-only', BASE).decode().splitlines():
    if n in allowed:
        continue
    check((ROOT / n).read_bytes() == git('show', BASE + ':' + n), 'protected original changed: ' + n)
    protected.append(n)

manifest = read('source-sha256.json')
for n, digest in manifest.items():
    check(sha((ROOT / n).read_bytes()) == digest == sha(git('show', TESTED + ':' + n)), 'tested source mismatch: ' + n)

# Prove optional hook only adds code; inherited success conditions not replaced.
diff = git('diff', BASE, '--', 'tests/combat/verify.py').decode()
check(not any(line.startswith('-') and not line.startswith('---') for line in diff.splitlines()), 'existing runner lines removed')
ns = {'__name__': 'm403a_review_import'}
exec(compile((ROOT / 'tests/combat/verify.py').read_text(), 'verify.py', 'exec'), ns)
validator = ns['validate_m403a_report']
report = read('m4-03a-scenarios.json')
log = (Path('/tmp/wanderer-m403a-final-20261107') / 'm4-queue-foundation-proof.log').read_text()
mutations = []
with tempfile.TemporaryDirectory(prefix='m403a-report-review-') as d:
    path = Path(d) / 'report.json'
    path.write_text(json.dumps(report))
    check(validator(path, log), 'valid actual report rejected')
    for label, mutate in [
        ('count bool', lambda r: r.update(independent_cases=True)),
        ('count fraction', lambda r: r.update(assertion_checks=1165.0)),
        ('missing case', lambda r: r['cases'].pop()),
        ('duplicate case ID', lambda r: r['cases'][1].update(id=r['cases'][0]['id'])),
        ('failed case', lambda r: r['cases'][0].update(actual='FAIL')),
        ('skipped case', lambda r: r['cases'][0].update(actual='SKIP')),
        ('missing assertion', lambda r: r['cases'][0]['assertions'].pop()),
        ('false assertion', lambda r: r['cases'][0]['assertions'][0].update(passed=False)),
        ('bool assertion', lambda r: r['cases'][0]['assertions'][0].update(passed=1)),
        ('wrong case count', lambda r: r['cases'][0].update(assertion_count=0)),
        ('extra root', lambda r: r.update(extra=True)),
        ('nonzero failures', lambda r: r.update(failures=1)),
        ('frame count', lambda r: r.update(per_frame_checks=1))]:
        r = copy.deepcopy(report)
        mutate(r)
        path.write_text(json.dumps(r))
        result = not validator(path, log)
        check(result, 'report validator accepted ' + label)
        mutations.append({'case': label, 'actual': 'PASS' if result else 'FAIL'})
    for label, content in [('duplicate JSON key', '{"suite":"a","suite":"b"}'),
                           ('nonfinite NaN', '{"value":NaN}'), ('nonfinite infinity', '{"value":Infinity}'),
                           ('malformed JSON', '{')]:
        path.write_text(content)
        result = not validator(path, log)
        check(result, 'report parser accepted ' + label)
        mutations.append({'case': label, 'actual': 'PASS' if result else 'FAIL'})
    path.write_text(json.dumps(report))
    for label, invalid_log in [('missing stdout', ''), ('wrong total stdout', log.replace('1165 checks', '1164 checks')),
                                ('duplicate summary', log + 'RESULT: 1165 checks, 0 failures\n')]:
        result = not validator(path, invalid_log)
        check(result, 'report validator accepted ' + label)
        mutations.append({'case': label, 'actual': 'PASS' if result else 'FAIL'})

def slug(value):
    value = re.sub(r'<[^>]*>', '', value).lower().replace('`', '')
    return ''.join(c for c in value if c.isspace() or c in '-_' or unicodedata.category(c)[0] in 'LNM').replace(' ', '-')

anchors = {}
mds = sorted(ROOT.glob('*.md')) + sorted((ROOT / 'docs').glob('*.md')) + sorted((ROOT / 'tests').glob('*/README.md'))
for p in mds:
    text = p.read_text()
    names = set(re.findall(r'<a\s+(?:id|name)="([^"]+)"', text))
    seen = {}
    for heading in re.findall(r'^#{1,6}\s+(.+?)\s*#*$', text, re.MULTILINE):
        name = slug(heading)
        suffix = seen.get(name, 0)
        names.add(name + (f'-{suffix}' if suffix else ''))
        seen[name] = suffix + 1
    anchors[p.resolve()] = names
links = 0
fragments = 0
for p in mds:
    for value in re.findall(r'\[[^\]]*\]\(([^)]+)\)', p.read_text()):
        if '://' in value or value.startswith(('mailto:', 'data:')):
            continue
        value = value.split(' "', 1)[0].strip('<>')
        file, _, fragment = value.partition('#')
        target = (p.parent / unquote(file)).resolve() if file else p.resolve()
        links += 1
        check(target.exists(), f'broken local link {p.relative_to(ROOT)} -> {value}')
        if fragment and target.suffix == '.md':
            fragments += 1
            check(unquote(fragment) in anchors.get(target, set()), f'broken fragment {p.relative_to(ROOT)} -> {value}')

zips = []
for p in DEST.glob('*.zip'):
    with zipfile.ZipFile(p) as z:
        check(z.testzip() is None, 'invalid ZIP ' + p.name)
        zips.append({'file': p.name, 'entries': len(z.namelist()), 'actual': 'PASS'})
check(subprocess.run(['git', 'diff', '--check'], cwd=ROOT, capture_output=True).returncode == 0, 'git diff --check failed')
for name in ['final-results.json', 'canonical-results.json']:
    stages = read(name)
    check(all(r['status'] == 'PASS' and r['exit_code'] == 0 and not r['timed_out'] for r in stages), 'runtime result failed: ' + name)
    check(all(len(r['errors']) == (5 if r['step'] == 'invalid-actions' else 0) for r in stages), 'unexpected error: ' + name)

operations = [
    {'operation': 'advance', 'input': 'exact5/types', 'authority': 'external owned capability',
     'identity': 'session/generation/queue', 'phase': 'OPEN', 'revision': 'expected current; +1 unavailable only',
     'mutation': 'one unavailable disposition/cursor only', 'result': 'READY/APPLIED or REJECTED with exact reason',
     'rejection': 'N-all', 'retry': 'READY/rejection repeatable', 'duplicate': 'published skip replay stale revision',
     'snapshot': 'detached', 'test': 'focused scenario assertions and full before/after roots'},
    {'operation': 'restart', 'input': 'exact6 envelope/exact fixture/actor/plan schemas',
     'authority': 'external owned capability', 'identity': 'session/current generation/queue',
     'phase': 'UNINITIALIZED/OPEN only; no legal SEALED transition in A',
     'revision': 'expected current; G+1/revision0', 'mutation': 'complete detached candidate root once',
     'result': 'APPLIED/RESTARTED or REJECTED with exact reason', 'rejection': 'N-all',
     'retry': 'old generation rejects', 'duplicate': 'recycled actor IDs do not recycle queue identity',
     'snapshot': 'detached', 'test': 'invalid last actor/plan retains valid opportunity; old request rejection'},
    {'operation': 'reads/progress diagnostic', 'input': 'no mutation request; actor ID or exact7 pure facts',
     'authority': 'none to read', 'identity': 'copy of current root; pure synthetic facts never imported',
     'phase': 'no publication', 'revision': 'unchanged', 'mutation': 'none',
     'result': 'derived view only', 'rejection': 'N-all', 'retry': 'same inputs same result',
     'duplicate': 'no grants/receipts/counters', 'snapshot': 'deep detached',
     'test': 'copy isolation and R49-01 predicate-only cases; full M403-44 deferred'}]

result = {'actual': 'PASS' if not errors else 'FAIL', 'errors': errors,
          'changed_file_scope': sorted(changed), 'preexisting_unchanged_blobs_outside_allowed': len(protected),
          'tested_source_hashes_match_commit_snapshot_delivery': len(manifest),
          'Markdown_files': len(mds), 'local_links': links, 'fragments': fragments,
          'optional_report_validator_adversarial_checks': mutations,
          'existing_runner_lines_removed': False, 'archive_integrity': zips,
          'operations_contract_audit': operations,
          'cross_contract': ['source/API/test schemas aligned', 'all invalid mutations N-all',
              'revision only on publication', 'dispositions never receipts', 'snapshots never authority',
              'reset identity binds generation', 'full M403 scenarios not promoted by A subsets'],
          'not_run': ['independent code/evidence review', 'GUI/keyboard/visual acceptance', 'B/C action/close/terminal integration'],
          'commands': ['python3 /tmp/wanderer_m403a_review.py', 'git diff --check']}
(DEST / 'review-checks.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({k: v for k, v in result.items() if k in ['actual', 'errors', 'preexisting_unchanged_blobs_outside_allowed',
                 'tested_source_hashes_match_commit_snapshot_delivery', 'Markdown_files', 'local_links', 'fragments']}, indent=2))
if errors:
    raise SystemExit(1)
