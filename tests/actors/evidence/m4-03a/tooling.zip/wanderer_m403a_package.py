import copy
import hashlib
import json
from pathlib import Path
import re
import shlex
import subprocess
import zipfile

ROOT = Path('/Applications/wanderer')
BASE = '67d68bb1f78fa8efedcb719079a4487c531c49d4'
TESTED = 'ad0e95ced3a7f52651d4dc671ef64634d3d148f9'
FINAL = Path('/tmp/wanderer-m403a-final-20261107')
CANON = Path('/tmp/wanderer-m403a-canonical-20261107-2')
REFERENCE = Path('/tmp/wanderer-m3a04-reference-20261105-2')
DEST = ROOT / 'tests/actors/evidence/m4-03a'
DEST.mkdir(parents=True, exist_ok=True)

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)

def read(path):
    return json.loads(Path(path).read_text())

def put(name, value):
    (DEST / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def sha(content):
    return hashlib.sha256(content).hexdigest()

final = read(FINAL / 'results.json')
canonical = read(CANON / 'results.json')
scenarios = read(FINAL / 'm4-03a-scenarios.json')
assert len(final) == 77 and len(canonical) == 73
assert all(r['status'] == 'PASS' and r['exit_code'] == 0 and not r['timed_out'] for r in final + canonical)
assert scenarios['failures'] == 0
put('final-results.json', final)
put('canonical-results.json', canonical)
put('m4-03a-scenarios.json', scenarios)

counts = []
for stage in canonical:
    a = re.findall(r'RESULT: (\d+) checks, 0 failures', (CANON / stage['log']).read_text())
    b = re.findall(r'RESULT: (\d+) checks, 0 failures', (FINAL / stage['log']).read_text())
    if a:
        counts.append({'suite': stage['step'], 'canonical_checks': int(a[-1]),
                       'candidate_checks': int(b[-1]), 'actual': 'PASS' if a == b else 'FAIL'})
assert all(c['actual'] == 'PASS' for c in counts)
put('inherited-counts.json', counts)

reference_results = read(REFERENCE / 'results.json')
assert reference_results == read(ROOT / 'tests/actors/evidence/m4-01/reference-results.json')
reference_commit = '1728c5e678c5065278d1251d50449a8820eb5dae'
reference_files = []
for name in git('ls-tree', '-r', '--name-only', reference_commit).decode().splitlines():
    p = Path(name)
    if p.suffix in ['.gd', '.tscn', '.uid', '.png', '.svg'] or p.name == 'project.godot' or name == 'tests/combat/verify.py':
        digest = sha(git('show', reference_commit + ':' + name))
        assert sha((REFERENCE / 'snapshot' / name).read_bytes()) == digest
        reference_files.append({'path': name, 'sha256': digest})
reference_provenance = {'status': 'PASS', 'commit': reference_commit, 'inherited_not_rerun': True,
    'results_equal_durable_record': True, 'durable_record': 'tests/actors/evidence/m4-01/reference-results.json',
    'stages': len(reference_results), 'tracked_source_matches': reference_files}
put('reference-provenance.json', reference_provenance)

traces = [read(p / 'presentation-traces.json')['traces'] for p in [CANON, FINAL, REFERENCE]]
assert traces[0] == traces[1] == traces[2]
trace_comparison = {'actual': 'PASS', 'expected': 'Exact Legacy equality, candidate/fresh canonical/provenanced pre-cutover reference',
    'canonical': BASE, 'tested': TESTED, 'reference': reference_commit, 'cases': len(traces[0]),
    'frames': sum(len(c['frames']) for c in traces[0]),
    'canonical_trace_sha256': sha((CANON / 'presentation-traces.json').read_bytes()),
    'candidate_trace_sha256': sha((FINAL / 'presentation-traces.json').read_bytes()),
    'reference_trace_sha256': sha((REFERENCE / 'presentation-traces.json').read_bytes())}
put('trace-comparison.json', trace_comparison)

manifest = read(FINAL / 'source-sha256.json')
canonical_manifest = read(CANON / 'source-sha256.json')
source_matches = []
for name, digest in manifest.items():
    values = {'tested_commit': sha(git('show', TESTED + ':' + name)),
              'snapshot': sha((FINAL / 'snapshot' / name).read_bytes()),
              'current': sha((ROOT / name).read_bytes())}
    assert all(value == digest for value in values.values()), name
    source_matches.append({'path': name, 'sha256': digest, **values, 'actual': 'PASS'})
for name, digest in canonical_manifest.items():
    assert sha(git('show', BASE + ':' + name)) == digest, name
protected = [name for name in canonical_manifest if name != 'tests/combat/verify.py']
assert all(manifest[name] == canonical_manifest[name] for name in protected)
put('source-sha256.json', manifest)
put('source-comparison.json', {'actual': 'PASS', 'canonical_commit': BASE, 'tested_commit': TESTED,
    'tested_source_files': len(manifest), 'matches': source_matches,
    'canonical_snapshot_matches_commit': len(canonical_manifest),
    'canonical_protected_source_matches': len(protected), 'protected_files': protected,
    'allowed_existing_source_change': 'tests/combat/verify.py optional hook only',
    'post_test_changes': 'Markdown and new evidence only; runtime/test/runner/UID hashes remain identical'})

def case_ids(needle):
    return [c['id'] for c in scenarios['cases'] if needle in c['expected']]

coverage = {'scope': 'A foundation only; no promotion of historical M403 design rows',
    'case_count': scenarios['independent_cases'], 'assertion_count': scenarios['assertion_checks'],
    'per_frame_checks': 0,
    'matrix': [
        {'id': 'M403-11', 'status': 'PARTIAL / FOUNDATION-ONLY', 'cases': case_ids('Consecutive unavailable'),
         'proven': 'Unavailable dispositions and stopping at eligible NPC, actors/plan unchanged',
         'deferred': 'Required preceding real Player/NPC action receipts; eligible-to-Enemy traversal after real completions'},
        {'id': 'M403-37', 'status': 'PARTIAL / FOUNDATION-ONLY', 'cases': case_ids('Atomic restart creates'),
         'proven': 'Generation reset and stale advance/reset request rejection', 'deferred': 'LOCKED/APPLIED action callbacks require B/C'},
        {'id': 'M403-38', 'status': 'PARTIAL / FOUNDATION-ONLY', 'cases': case_ids('Atomic restart creates'),
         'proven': 'Reused actor IDs do not accept old generation queue requests', 'deferred': 'Real action/close/Abort grants absent'},
        {'id': 'M403-39', 'status': 'PARTIAL / FOUNDATION-ONLY', 'cases': case_ids('Invalid Restart variant'),
         'proven': 'Malformed/duplicate fixtures are N-all and legitimate old queue opportunity remains usable',
         'deferred': 'Pending real effect retains ability to impact'},
        {'id': 'M403-40', 'status': 'PARTIAL / FOUNDATION-ONLY', 'cases': case_ids('Protocol precedence') + case_ids('Missing/foreign capability'),
         'proven': 'Stale revision and forged/missing capability reject before cursor publication',
         'deferred': 'Owned action lock/forged token authorization ID'},
        {'id': 'M403-44', 'status': 'DEFERRED TO B/C', 'cases': case_ids('Pure diagnostic predicate only'),
         'proven': 'Pure R49-01 SUSPENDED predicates, read-only repeatability, no stored phase',
         'deferred': 'Both full nonterminal boundaries, real seal/open-next operations, retry/stale revisions against those boundaries; NOT end-to-end PASS'},
        {'id': 'M403-47', 'status': 'FULLY PROVEN', 'scope': 'This A candidate regression/preservation only',
         'evidence': ['final-results.json', 'inherited-counts.json', 'source-comparison.json'],
         'proven': 'Unchanged Guidance v1/R1/Pending/Frozen/Restart assertions and protected production hashes'},
        {'id': 'M403-48', 'status': 'FULLY PROVEN', 'scope': 'This A candidate automated regression only, not playable/visual acceptance',
         'evidence': ['final-results.json', 'canonical-results.json', 'trace-comparison.json'],
         'proven': 'Fresh all-flags candidate/canonical and exact Legacy differential; new A cases separate'}],
    'other_M403_gameplay_rows': 'DEFERRED TO B/C / NOT RUN, historical table unchanged',
    'M402-06': 'BLOCKED DEPENDENCY — pending-rescue end-to-end proof unchanged',
    'M402-24': 'PARTIAL — original authenticated unused wrong-round issuer path still absent',
    'SEALED_restart': 'BLOCKED DEPENDENCY — legal SEALED/Abort producer absent; validator rejection only',
    'GUI_keyboard_visual_acceptance': 'NOT RUN'}
put('coverage.json', coverage)

def archive_run(path, target, include_source=False):
    with zipfile.ZipFile(DEST / target, 'w', zipfile.ZIP_DEFLATED) as z:
        for p in sorted(path.iterdir()):
            if p.is_file() and p.suffix in ['.log', '.exit', '.json']:
                z.write(p, p.name)
        if include_source:
            for p in sorted((path / 'snapshot').rglob('*')):
                if p.is_file() and p.suffix in ['.gd', '.py', '.uid'] and '.godot' not in p.parts:
                    z.write(p, str(p.relative_to(path)))

archive_run(FINAL, 'logs.zip')
archive_run(CANON, 'canonical-logs.zip')
dev_names = ['wanderer-m403a-canonical-20261107', 'wanderer-m403a-development-20261107-1',
             'wanderer-m403a-development-20261107-2', 'wanderer-m403a-development-20261107-3']
with zipfile.ZipFile(DEST / 'development-logs.zip', 'w', zipfile.ZIP_DEFLATED) as z:
    for name in dev_names:
        path = Path('/tmp') / name
        for p in sorted(path.rglob('*')):
            if not p.is_file() or '.godot' in p.parts:
                continue
            if p.parent == path and p.suffix in ['.log', '.exit', '.json'] \
                    or 'snapshot' in p.parts and p.suffix in ['.gd', '.py', '.uid']:
                z.write(p, name + '/' + str(p.relative_to(path)))

flags = '--npc-proof --actor-proof --ownership-proof --party-foundation-proof --party-turn-proof --party-playable-proof --presentation-proof --autonomous-main-proof --main-cutover-proof --guidance-data-proof --guidance-decision-proof --guidance-main-proof --m4-data-proof --m4-atomic-clock-proof'
engine = '/Applications/Godot.app/Contents/MacOS/Godot'
canonical_command = f'python3 /tmp/wanderer-m403a-canonical-source-20261107/tests/combat/verify.py --godot {engine} --output {CANON} {flags} --cutover-baseline {REFERENCE}'
final_command = f'python3 tests/combat/verify.py --godot {engine} --output {FINAL} {flags} --m4-queue-foundation-proof --cutover-baseline {REFERENCE}'
run_record = {'task': 'M4-03A — Isolated Queue / Eligibility Foundation Implemented Candidate',
    'date': '2026-11-07', 'timezone': 'Asia/Bangkok', 'repository': 'shanwinder/wanderer',
    'canonical_branch': 'visual-combat-test-1', 'canonical_commit': BASE, 'tested_source_sha': TESTED,
    'branch': 'codex/m4-03a-isolated-queue-eligibility-foundation',
    'delivery_head': {'resolution': 'Exact final SHA recorded in Draft PR body and final owner report; git rev-parse HEAD on delivered branch',
                      'reason': 'A committed file cannot contain its own Git commit hash; this record and its source-manifest proof travel with delivery',
                      'tested_relation': 'Only four authorized Markdown files and new evidence added after tested source; all 117 source hashes verified'},
    'engine': '4.7.2.stable.official.ed1daf0bf', 'executable': engine,
    'authorization': 'Owner attached M4-03A implementation task dated 7 November 2026; A only, Draft PR and stop',
    'preflight': {'initial_tree_clean': True, 'initial_branch': 'visual-combat-test-1',
        'local_fetched_live_merge_base': BASE, 'PR49_merged': True, 'PR49_merge_sha': BASE,
        'PR49_local_remote_branch_absent': True, 'dedicated_M403A_branch_PR_before_work': 'none',
        'PR2_PR17': 'open/unmerged; head commits fac99aa/c162d63 not ancestors of canonical; untouched'},
    'commands': {'version': engine + ' --version', 'canonical': canonical_command, 'final': final_command,
        'focused': f'python3 tests/combat/verify.py --godot {engine} --output /tmp/wanderer-m403a-development-20261107-3 --m4-queue-foundation-proof',
        'packaging': 'python3 /tmp/wanderer_m403a_package.py', 'review': 'python3 /tmp/wanderer_m403a_review.py; git diff --check',
        'canonical_source': 'git archive 67d68bb1f78fa8efedcb719079a4487c531c49d4 | tar -x -C /tmp/wanderer-m403a-canonical-source-20261107; git init and git add in that disposable source only'},
    'execution_access': 'Final/canonical commands executed outside filesystem sandbox for macOS certificate/settings access, same engine/test conditions; no test gate changes',
    'outputs': {'canonical': str(CANON.resolve()), 'final': str(FINAL.resolve()), 'reference': str(REFERENCE.resolve())},
    'expected': 'Focused A proof PASS; inherited suites/counts/source unchanged; Legacy exact; no unexpected errors/timeouts',
    'actual': {'status': 'PASS within A executable scope', 'canonical_stages': len(canonical), 'candidate_stages': len(final),
        'runner_exit_codes': {'canonical': 0, 'final': 0, 'focused_corrected': 0},
        'all_stage_exit_codes': 0, 'independent_cases': scenarios['independent_cases'],
        'assertion_checks': scenarios['assertion_checks'], 'per_frame_checks': 0,
        'M401_cases': 78, 'M401_checks': 525, 'M402_cases': 55, 'M402_checks': 1188,
        'identical_inherited_count_suites': len(counts), 'legacy_cases': trace_comparison['cases'],
        'legacy_frames': trace_comparison['frames'], 'negative_expected_errors': 5,
        'unexpected_errors': 0, 'timeouts': 0, 'tested_source_hashes': len(manifest),
        'canonical_protected_source_hashes': len(protected)},
    'reference_provenance': {'file': 'reference-provenance.json', 'source_matches': len(reference_files), 'stages': 44, 'inherited_not_rerun': True},
    'development': [
        {'run': dev_names[0], 'runner_exit': 1, 'status': 'FAIL — sandbox environment',
         'actual': 'Unchanged canonical import exits0 but reports macOS CA/settings errors; not counted as verified baseline'},
        {'run': dev_names[1], 'runner_exit': 1, 'status': 'FAIL — code defect',
         'actual': '83 cases,1045 checks,3 failed assertions and3 engine errors: invalid-type actor ID compared to String; fixed exists guard'},
        {'run': dev_names[2], 'runner_exit': 1, 'status': 'FAIL — harness defect despite Godot exit0',
         'actual': '92 cases,1139 checks,0 assertion failures but10 engine errors formatting wrong-type capability; runner correctly fails'},
        {'run': dev_names[3], 'runner_exit': 0, 'status': 'PASS — corrected focused run',
         'actual': '94 cases,1165 assertions,0 failures/errors; no failed run relabelled PASS'}],
    'not_run': scenarios['deferred'] + ['GUI/F5/F6 manual keyboard/visual acceptance', 'M4-03B/C implementation', 'NPC rescue/retreat policy', 'production integration'],
    'limits': ['Finite foundation, no real effect/completion producer; eligible opportunity remains current',
        'Pure diagnostic facts do not prove M403-44 end-to-end; no seal/open-next API',
        'No legal SEALED transition in A; Abort-before-Restart integration deferred',
        'Roster cap discrepancy recorded from actual isolated validators; no arbitrary caps added',
        'Synchronous single-threaded proof; capability/underscore conventions are not hostile-code security',
        '117 tested hashes verified after documentation/evidence changes; no second runtime run claimed'],
    'stop': 'Draft PR / Awaiting Independent Code & Evidence Review; no merge, auto-merge, branch deletion or B/C follow-on'}
put('run-record.json', run_record)
print(json.dumps(run_record['actual'], indent=2))
