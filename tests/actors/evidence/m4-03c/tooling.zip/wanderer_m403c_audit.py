from pathlib import Path
import copy,hashlib,json,re,subprocess,tempfile,unicodedata,zipfile
from urllib.parse import unquote
ROOT=Path('/Applications/wanderer');DEST=ROOT/'tests/actors/evidence/m4-03c';BASE='2c59e8d8e27c92c92344adcba9eded0d297cc547';TESTED='5b37e061027649c6ef4be5c61a963659a82ed939'
errors=[]
def check(ok,msg):
 if not ok:errors.append(msg)
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT)
def read(n):return json.loads((DEST/n).read_text())
allowed={'README.md','docs/README.md','tests/actors/README.md','tests/combat/README.md','tests/combat/verify.py'}
for p in ['scripts/m4/m403_outcome_classifier.gd','scripts/m4/m403_summary.gd','scripts/m4/m403_terminal_rules.gd','scripts/m4/m403_terminal_encounter.gd','tests/actors/m4_03_outcome_summary_proof.gd']:allowed.update([p,p+'.uid'])
changed=set(git('diff',BASE,'--name-only').decode().splitlines())|set(git('ls-files','--others','--exclude-standard').decode().splitlines())
check(all(n in allowed or n.startswith('tests/actors/evidence/m4-03c/') for n in changed),'changed-file scope')
protected=[]
for n in git('ls-tree','-r','--name-only',BASE).decode().splitlines():
 if n not in allowed:
  check((ROOT/n).read_bytes()==git('show',BASE+':'+n),'protected blob changed '+n);protected.append(n)
manifest=read('source-sha256.json')
for n,h in manifest.items():check(hashlib.sha256((ROOT/n).read_bytes()).hexdigest()==h==hashlib.sha256(git('show',TESTED+':'+n)).hexdigest(),'tested source mismatch '+n)
diff=git('diff',BASE,'--','tests/combat/verify.py').decode();check(not any(x.startswith('-') and not x.startswith('---') for x in diff.splitlines()),'runner removed existing line')
ns={'__name__':'m403c_audit_import'};exec(compile((ROOT/'tests/combat/verify.py').read_text(),'verify.py','exec'),ns)
validator=ns['validate_m403c_report'];report=json.loads(Path('/tmp/wanderer-m403c-final-20261108-2/m4-03c-scenarios.json').read_text());log=Path('/tmp/wanderer-m403c-final-20261108-2/m4-outcome-summary-proof.log').read_text();variants=[]
with tempfile.TemporaryDirectory(prefix='m403c-report-audit-') as tmp:
 p=Path(tmp)/'report.json';p.write_text(json.dumps(report));check(validator(p,log),'actual report invalid')
 for name,mutate in [('bool independent count',lambda r:r.update(independent_cases=True)),('fraction assertion count',lambda r:r.update(assertion_checks=5458.0)),('missing case',lambda r:r['cases'].pop()),('duplicate ID',lambda r:r['cases'][1].update(id=r['cases'][0]['id'])),('case FAIL',lambda r:r['cases'][0].update(actual='FAIL')),('case SKIP',lambda r:r['cases'][0].update(actual='SKIP')),('missing assertion',lambda r:r['cases'][0]['assertions'].pop()),('false Boolean',lambda r:r['cases'][0]['assertions'][0].update(passed=False)),('integer masquerades Boolean',lambda r:r['cases'][0]['assertions'][0].update(passed=1)),('zero case count',lambda r:r['cases'][0].update(assertion_count=0)),('extra root field',lambda r:r.update(extra=True)),('nonzero failures',lambda r:r.update(failures=1)),('nonzero perframe',lambda r:r.update(per_frame_checks=1)),('wrong suite',lambda r:r.update(suite='M4-03B retreat transaction')),('unknown assertion field',lambda r:r['cases'][0]['assertions'][0].update(extra=True))]:
  r=copy.deepcopy(report);mutate(r);p.write_text(json.dumps(r));ok=not validator(p,log);check(ok,'validator accepted '+name);variants.append({'case':name,'actual':'PASS' if ok else 'FAIL'})
 for name,s in [('duplicate JSON key','{"suite":"a","suite":"b"}'),('NaN','{"value":NaN}'),('Infinity','{"value":Infinity}'),('malformed JSON','{')]:
  p.write_text(s);ok=not validator(p,log);check(ok,'parser accepted '+name);variants.append({'case':name,'actual':'PASS' if ok else 'FAIL'})
 p.write_text(json.dumps(report))
 for name,s in [('missing stdout',''),('wrong stdout total',log.replace('5458 checks','5457 checks')),('duplicate stdout summary',log+'RESULT: 5458 checks, 0 failures\n'),('duplicate stdout CASE',log+'CASE M403C-01: PASS\n'),('false PASS stdout',log.replace('CASE M403C-01: PASS','CASE M403C-01: FAIL'))]:
  ok=not validator(p,s);check(ok,'validator accepted '+name);variants.append({'case':name,'actual':'PASS' if ok else 'FAIL'})
 p.unlink();ok=not validator(p,log);check(ok,'missing report accepted');variants.append({'case':'missing report','actual':'PASS' if ok else 'FAIL'})
check(sum(c['assertion_count'] for c in report['cases'])==5458 and len(report['cases'])==97,'actual report counts')
# Every raw successful/failed operation observation retains before/input/after. Pure cases have explicit distinct labels.
for c in report['cases']:
 check(bool(c['steps']),c['id']+' missing observed steps')
 for s in c['steps']:
  if 'method' in s:
   check(all(k in s for k in ['input','before','after','expected_reason','expected_status','actual','N_all']),c['id']+' missing input/snapshots')
   if s['N_all']:check(s['before']==s['after'],c['id']+' rejected/read mutation')
# GitHub-compatible local links/fragment audit across existing guides.
def slug(v):
 v=re.sub(r'<[^>]*>','',v).lower().replace('`','')
 return ''.join(c for c in v if c.isspace() or c in '-_' or unicodedata.category(c)[0] in 'LNM').replace(' ','-')
mds=sorted(ROOT.glob('*.md'))+sorted((ROOT/'docs').glob('*.md'))+sorted((ROOT/'tests').glob('*/README.md'));anchors={}
for p in mds:
 names=set(re.findall(r'<a\s+(?:id|name)="([^"]+)"',p.read_text()));seen={}
 for h in re.findall(r'^#{1,6}\s+(.+?)\s*#*$',p.read_text(),re.M):
  n=slug(h);suffix=seen.get(n,0);names.add(n+(f'-{suffix}' if suffix else ''));seen[n]=suffix+1
 anchors[p.resolve()]=names
links=fragments=0
for p in mds:
 for v in re.findall(r'\[[^\]]*\]\(([^)]+)\)',p.read_text()):
  if '://' in v or v.startswith(('mailto:','data:')):continue
  v=v.split(' "',1)[0].strip('<>');file,_,fragment=v.partition('#');target=(p.parent/unquote(file)).resolve() if file else p.resolve();links+=1
  check(target.exists(),f'broken link {p.relative_to(ROOT)} -> {v}')
  if fragment and target.suffix=='.md':fragments+=1;check(unquote(fragment) in anchors.get(target,set()),f'broken fragment {p.relative_to(ROOT)} -> {v}')
zips=[]
for p in DEST.glob('*.zip'):
 with zipfile.ZipFile(p) as z:check(z.testzip() is None,'bad ZIP '+p.name);zips.append({'path':p.name,'entries':len(z.namelist()),'actual':'PASS'})
with zipfile.ZipFile(DEST/'m4-03c-scenarios.zip') as z:
 check(z.read('m4-03c-scenarios.json')==Path('/tmp/wanderer-m403c-final-20261108-2/m4-03c-scenarios.json').read_bytes(),'raw scenarios not exact')
index=read('case-index.json');check(index['assertion_checks']==5458 and index['independent_cases']==97,'case index count')
for c,i in zip(report['cases'],index['cases']):check(all(c[k]==i[k] for k in ['id','expected','actual','assertion_count','failure_count','assertions']),'case index assertions not exact '+c['id'])
for n in ['final-results.json','canonical-results.json']:
 rows=read(n);check(all(r['status']=='PASS' and r['exit_code']==0 and not r['timed_out'] for r in rows),'failed runtime '+n)
 check(all(len(r['errors'])==(5 if r['step']=='invalid-actions' else 0) for r in rows),'unexpected engine errors '+n)
coverage=read('coverage.json')['rows'];check([r['id'] for r in coverage]==[f'M403-{i:02}' for i in range(1,49)],'design row coverage IDs')
for r in coverage:
 for id in r['case_ids']:check(id in {c['id'] for c in report['cases']},'unknown evidence case '+id)
check([r for r in coverage if r['id']=='M403-44'][0]['case_ids']==['M403C-42','M403C-43'],'R49 two-boundary refs')
check(subprocess.run(['git','diff','--check'],cwd=ROOT,capture_output=True).returncode==0,'git diff --check')
for n in ['fac99aa96c08b3e53a9d8db74a0025b4153503bd','c162d63385ca8d6dd03a6b5cc5c0dbce2afda694']:check(subprocess.run(['git','merge-base','--is-ancestor',n,BASE],cwd=ROOT).returncode==1,'unmerged proposal became ancestor')
check(git('rev-list','--parents','-n','1',BASE).decode().split()==[BASE,'5cf53e0d145d3a518fcedd458ba2a892eb52cb1f'],'PR51 single squash parent')
for p in ['docs/M4_03_Queue_Retreat_Outcome_Contract.md','docs/M4_02_Rescue_Clock_Death_Contract.md','docs/M4_Down_Help_Death_Retreat_Architecture.md','tests/actors/m4_03_queue_foundation_proof.gd','tests/actors/m4_03_retreat_proof.gd']:
 check((ROOT/p).read_bytes()==git('show',BASE+':'+p),'original approved contract/assertions changed '+p)
result={'actual':'PASS' if not errors else 'FAIL','errors':errors,'tested_source':TESTED,'changed_file_scope':sorted(changed),'tested_source_hashes_verified':len(manifest),'protected_existing_blobs':len(protected),'Markdown_files':len(mds),'local_links':links,'fragments':fragments,'optional_report_adversarial_audit':variants,'existing_runner_lines_removed':False,'archive_integrity':zips,'case_index_assertions_exact':5458,'raw_report_preserved_exactly':True,'original_contracts_and_AB_assertions':'unchanged','independent_review':'PENDING; this is self-audit only','not_run':read('run-record.json')['not_run']}
(DEST/'review-checks.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['actual','errors','tested_source_hashes_verified','protected_existing_blobs','Markdown_files','local_links','fragments']},ensure_ascii=False,indent=2));print('Malformed reports/stdout rejected:',len(variants))
if errors:raise SystemExit(1)
