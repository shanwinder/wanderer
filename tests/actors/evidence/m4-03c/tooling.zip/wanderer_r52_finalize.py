from pathlib import Path
import json,hashlib,subprocess,zipfile
root=Path('/Applications/wanderer');d=root/'tests/actors/evidence/m4-03c'
def read(n):return json.loads((d/n).read_text())
def write(n,v):(d/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
before='8f007f3a6c2693819f05cf26bb71e453866fab67';tested='d583b4b6fdd3226178e4f5b4e916c874a82d83c4'
history=read('development-history.json')
with zipfile.ZipFile(d/'r52-development-logs.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in ['focused-1','focused-2']:
  p=Path('/tmp/wanderer-r52-'+name);rs=json.loads((p/'results.json').read_text())
  for f in p.iterdir():
   if f.is_file():z.write(f,name+'/'+f.name)
  for rel in ['scripts/m4/m403_terminal_rules.gd','tests/actors/m4_03_outcome_summary_proof.gd','tests/combat/verify.py']:
   z.write(p/'snapshot'/rel,name+'/source/'+rel)
  history.append({'run':str(p),'actual':'PASS' if all(x['status']=='PASS' for x in rs) else 'FAIL','runner_exit':0 if name=='focused-2' else 1,'stages':len(rs),'errors':[{'step':r['step'],'errors':r['errors']} for r in rs if r['errors']],'note':'Sandbox import exited0 but emitted macOS certificate/editor-settings errors; rejected, not counted PASS.' if name=='focused-1' else 'Fresh corrected source; 115 cases/6054 assertions; original A/B unchanged.','evidence':'r52-development-logs.zip!/'+name})
write('development-history.json',history)
record=read('run-record.json');record.update(task='R52-01 exact request correction — Awaiting Independent Follow-up Review',reviewed_head=before,authorization='Explicit owner R52-01 focused correction/tests/regression/evidence on existing Draft PR #52',preflight={'initial_tree':'clean at reviewed HEAD on existing PR52 branch','reviewed_head':before,'canonical_commit':record['canonical_commit'],'fetch':'git fetch origin succeeded; both refs matched live PR metadata','PR52':'OPEN / DRAFT / UNMERGED; existing branch reused','review':'https://github.com/shanwinder/wanderer/pull/52#pullrequestreview-5815436769'},development_history='development-history.json; historical failures retained in pre-r52-evidence.zip and development-logs.zip; current sandbox import FAIL plus successful focused run in r52-development-logs.zip',stop='Existing Draft PR #52; await Independent Follow-up Review of R52-01; no merge/auto-merge/branch deletion/M4-04/M4-05/production')
record['commands'].update(package='python3 /tmp/wanderer_r52_package.py && python3 /tmp/wanderer_r52_finalize.py',audit='python3 /tmp/wanderer_r52_audit.py; git diff --check',canonical_workdir='/tmp/wanderer-r52-canonical-source (detached canonical commit)',candidate_workdir='/Applications/wanderer',focused='python3 tests/combat/verify.py --godot /Applications/Godot.app/Contents/MacOS/Godot --output /tmp/wanderer-r52-focused-2 --m4-outcome-summary-proof --m4-queue-foundation-proof --m4-retreat-transaction-proof')
record['evidence']=sorted(set(record['evidence']+['r52-01.json','r52-development-logs.zip','pre-r52-evidence.zip','evidence-sha256.json']))
write('run-record.json',record)
index=read('case-index.json')
protected=[]
allowed={'scripts/m4/m403_terminal_rules.gd','tests/actors/m4_03_outcome_summary_proof.gd','README.md','docs/README.md','tests/actors/README.md','tests/combat/README.md'}
for n in subprocess.check_output(['git','ls-tree','-r','--name-only',before],cwd=root,text=True).splitlines():
 if n in allowed or n.startswith('tests/actors/evidence/m4-03c/'):continue
 h=hashlib.sha256(subprocess.check_output(['git','show',before+':'+n],cwd=root)).hexdigest();assert h==sha(root/n),n;protected.append({'path':n,'sha256':h})
write('r52-01.json',{'task':'R52-01','actual':'PASS — author verification; independent follow-up PENDING','date':'2026-11-08 Asia/Bangkok','before_head':before,'tested_source_sha':tested,'delivery_head':'Resolve final SHA from PR #52 body; evidence-only/docs delta after tested source','engine':record['engine'],'executable':record['executable'],'commands':record['commands'],'schema_diff':{'SEAL':{'before':'ROUND exact6','after':'BASE exact5 = version, session, generation, expected_revision, queue_id'},'AUTHORIZE_ABORT':{'before':'ROUND + request_id + kind exact8','after':'BASE + request_id exact6'},'OPEN':'ROUND exact6 unchanged','close_event':'exact11 unchanged','witness':'exact12 unchanged'},'call_tree_audit':['facade _execute validates protocol before capability and Rules.apply repeats protocol','request_reason reads round_id only when present; SEAL/Abort requests cannot contain it','seal_candidate accepts only owned v/c, no caller payload; round/queue/witness/event derived internally','AUTHORIZE_ABORT reads only request_id after BASE validation; owned round/queue/session/generation and fixed ABORT issuer/kind, authorization count and new revision issue token','duplicate/phase/queue/revision precedence and one-root publication code unchanged'],'new_cases':index['cases'][97:],'existing_cases_rerun':{'strict_real_completion_and_clock':'C37–41','NO_REAL_PROGRESS_PLAN_EXHAUSTED':'C42–43','Abort_first_Close_first_Restart':'C44–49','original_C_cases':'C01–97 assertions retained; request helpers corrected'},'results':record['actual'],'inherited_regression':'regression-comparison.json; original A/B/M401/M402 tests unchanged','protected_vs_reviewed_head':protected,'source_manifest':'source-sha256.json; 131 exact tested-source/current/snapshot matches','canonical_protected':'protected-files.json; 351 canonical blobs unchanged','historical_evidence':'pre-r52-evidence.zip (exact pre-fix files; not relabelled new PASS)','development_runs':'development-history.json + r52-development-logs.zip','limitations':record['not_run'],'stop':record['stop']})
p=root/'README.md';p.write_text(p.read_text().replace('97 C cases /5,458','115 C cases /6,054'))
# Archive the exact tooling used; original tooling survives in pre-r52 archive.
with zipfile.ZipFile(d/'tooling.zip','w',zipfile.ZIP_DEFLATED) as z:
 for n in ['wanderer_r52_package.py','wanderer_r52_finalize.py','wanderer_r52_audit.py','wanderer_r52_docs.py']:z.write(Path('/tmp')/n,n)
print('R52 evidence/history/protected scope refreshed')

with zipfile.ZipFile(d/"pre-r52-evidence.zip") as z:
 for n in ["packaging-audit-history.json","development-logs.zip"]:(d/n).write_bytes(z.read(n))
