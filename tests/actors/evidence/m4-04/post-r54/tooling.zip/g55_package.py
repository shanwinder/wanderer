from pathlib import Path
import json,subprocess,hashlib,re,zipfile,collections,shutil
base=Path('tests/actors/evidence/m4-04');out=base/'post-r54';out.mkdir(exist_ok=True)
canon='6cd7b842c07e308203f61bbaaff6339233567c68';old='af3c4161a0d5e72bafec46ae07561be5ec1fdc7c';tested='abb0727a892127d4b43f880af5890d68859d7f86'
sha=lambda b:hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_text())
def write(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
c=Path('/tmp/wanderer-g55-canonical-run');f=Path('/tmp/wanderer-g55-candidate-run')
for p,label,n in [(c,'canonical',88),(f,'candidate',94)]:
 r=load(p/'results.json');assert len(r)==n and all(x['status']=='PASS' and x['exit_code']==0 and not x.get('timed_out') for x in r)
 assert sum(len(x['errors']) for x in r)==5
 assert len(next(x for x in r if x['step']=='invalid-actions')['errors'])==5
 for name in ['results.json','source-sha256.json','cutover-release-gates.json','trace-comparison.json']:
  shutil.copy2(p/name,out/(label+'-'+name))
 report=load(p/'source-sha256.json')
 for path,h in report.items():
  assert sha((p/'snapshot'/path).read_bytes())==h==sha(subprocess.check_output(['git','show',(canon if label=='canonical' else tested)+':'+path])),path
shutil.copy2(f/'m4-04-scenarios.json',out/'m4-04-scenarios.json')
shutil.copy2('/tmp/wanderer-g55-validator-audit.json',out/'validator-audit.json')
assert len(load(out/'validator-audit.json'))==36 and all(x['rejected'] for x in load(out/'validator-audit.json'))
comparison=[]
for p in sorted(c.glob('*.log')):
 if p.name.endswith('.engine.log'):continue
 a=re.findall(r'RESULT: (\d+) checks, 0 failures',p.read_text());b=re.findall(r'RESULT: (\d+) checks, 0 failures',(f/p.name).read_text()) if (f/p.name).exists() else []
 if a:comparison.append({'suite':p.stem,'canonical':a,'candidate':b,'equal':a==b})
assert len(comparison)==23 and all(x['equal'] for x in comparison)
write(out/'regression-comparison.json',comparison)
a=load(c/'presentation-traces.json')['traces'];b=load(f/'presentation-traces.json')['traces'];ref=load(Path('/tmp/wanderer-m3a04-reference-20261105-2/presentation-traces.json'))['traces'];assert a==b==ref
write(out/'legacy-comparison.json',{'fresh_canonical_vs_candidate':True,'fresh_vs_retained_pre_cutover_reference':True,'cases':len(a),'frames':sum(len(x['frames']) for x in a),'historical_reference_engine_execution':'inherited, not rerun','all_three_trace_sha256':sha(json.dumps(a,sort_keys=True,separators=(',',':')).encode())})
r=load(f/'m4-04-scenarios.json');assert r['independent_cases']==128 and r['assertion_checks']==458 and r['failures']==0
assert len({x['id'] for x in r['cases']})==128 and sum(x['assertion_count'] for x in r['cases'])==458
assert all(z['passed'] is True for x in r['cases'] for z in x['assertions'])
assert all(x['actual']=='PASS' and x['failure_count']==0 for x in r['cases'])
write(out/'focused-summary.json',{k:r[k] for k in ['independent_cases','assertion_checks','failures','per_frame_checks','deferred','source_sha256']}|{'classifications':dict(collections.Counter(x['classification'] for x in r['cases'])),'unique_case_ids':True,'every_assertion_true':True,'real_owned_transaction_cases':{'ATTACK':'M404-124','RESCUE':'M404-125','RETREAT':'M404-126'},'locked_impact_complete_owned_receipts':'see finish() assertions and actual M403 reason/receipt checks in cases124–126; no mock receipts','case_128':'real serial Enemy second-hit SKIPPED, not mid-action external mutation'})
# Preserve every report, import/parse/startup/gameplay/negative log, engine log, and exit.
entries=[]
with zipfile.ZipFile(out/'logs.zip','w',zipfile.ZIP_DEFLATED) as z:
 for d,label in [(c,'canonical'),(f,'candidate')]:
  for p in sorted(d.iterdir()):
   if p.is_file():
    entry=label+'/'+p.name;z.write(p,entry);entries.append({'entry':entry,'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size})
 for label in ['canonical','candidate']:
  p=Path('/tmp/wanderer-g55-'+label+'-console.log');z.write(p,label+'/runner-console.log');entries.append({'entry':label+'/runner-console.log','sha256':sha(p.read_bytes()),'bytes':p.stat().st_size})
write(out/'archive-entries.json',entries)
with zipfile.ZipFile(out/'logs.zip') as z:
 assert all(sha(z.read(x['entry']))==x['sha256'] for x in entries)
flags='--npc-proof --actor-proof --ownership-proof --party-foundation-proof --party-turn-proof --party-playable-proof --presentation-proof --autonomous-main-proof --main-cutover-proof --guidance-data-proof --guidance-decision-proof --guidance-main-proof --m4-data-proof --m4-atomic-clock-proof --m4-queue-foundation-proof --m4-retreat-transaction-proof --m4-outcome-summary-proof'
record={
 'task':'G55-DOC-01 / existing Draft PR55 / post-PR54 canonical reconciliation',
 'pr54_merge_sha':canon,'new_canonical_sha':canon,'old_pr55_head':old,'original_tested_source_sha':'6187a4ff6dea0a5a983c21171e92db53eff6cd63',
 'new_pr55_head_at_fresh_run':tested,'new_tested_source_sha':tested,
 'delivery_head_resolution':'Read final live PR55 head_sha / PR body delivery HEAD. A commit cannot contain its own SHA; this evidence names the exact rebased tested ancestor. Only docs/evidence commits follow; final delivery is checked against these source manifests before push.',
 'preflight':{'initial_branch':'visual-combat-test-1','initial_local_HEAD':canon,'initial_fetched_canonical':canon,'live_canonical':canon,'local_feature_head':old,'fetched_feature_head':old,'live_feature_head':old,'old_merge_base':'0c5eef193da6265d1e7f502123711ba4753625ce','new_merge_base':canon,'initial_worktree_clean':True,'pr54':'MERGED, exact merge SHA confirmed via GitHub','pr55':'OPEN / DRAFT / UNMERGED, expected branch and original reviewed HEAD confirmed','pr2_pr17':'OPEN/DRAFT/UNMERGED, unrelated and untouched'},
 'rebase':{'command':'git rebase --onto origin/visual-combat-test-1 0c5eef193da6265d1e7f502123711ba4753625ce codex/m4-04-isolated-autonomous-decision-proof','original_feature_commits':5,'conflicts':['README.md','docs/README.md','docs/M4_04_Autonomous_Decision_Contract.md'],'resolution':'Manually combined canonical approved authority with candidate status/evidence; no blanket ours/theirs. Four runtime modules, focused proof, UIDs and runner byte-identical to original tested/delivery sources. Architecture unchanged from new canonical. No unrelated commits.'},
 'documentation_reconciliation':{'README.md':'approved canonical source + candidate/draft/follow-up status, links and remaining scope','docs/README.md':'one current authority and approved register link; historical C/design checkpoints attributed; stale current design-only statements corrected','docs/M4_04_Autonomous_Decision_Contract.md':'full canonical §2.1 unchanged; approved §§3–5 retained; current candidate128/458 and limits; original23 design rows preserved and map01–20 plus new21–23 mapping of executed slices/gaps; O4/O6/O7 retained','tests/actors/README.md':'original delivery paragraph explicitly historical; new post-rebase record link','tests/combat/README.md':'separate post-rebase reproduction/evidence link','architecture':'byte-identical to canonical; excluded from PR55 diff'},
 'engine':'4.7.2.stable.official.ed1daf0bf','godot':'/Applications/Godot.app/Contents/MacOS/Godot',
 'fresh_canonical':{'source':canon,'clean_worktree':'/tmp/wanderer-g55-canonical-source','command':'python3 tests/combat/verify.py --godot /Applications/Godot.app/Contents/MacOS/Godot --output '+str(c)+' '+flags+' --cutover-baseline /tmp/wanderer-m3a04-reference-20261105-2','stages':88,'PASS':88,'process_exit':0,'unexpected_errors':0,'timeouts':0,'expected_negative_errors':5,'results':'post-r54/canonical-results.json'},
 'fresh_candidate':{'source':tested,'command':'python3 tests/combat/verify.py --godot /Applications/Godot.app/Contents/MacOS/Godot --output '+str(f)+' '+flags+' --m4-autonomous-decision-proof --cutover-baseline /tmp/wanderer-m3a04-reference-20261105-2','stages':94,'PASS':94,'process_exit':0,'unexpected_errors':0,'timeouts':0,'expected_negative_errors':5,'results':'post-r54/candidate-results.json','snapshot_manifest':'141 source entries match tested Git commit and snapshot actual bytes; documentation edits after source snapshot do not change runtime/test/runner'},
 'expected':'88 canonical /94 candidate PASS;128 cases458 assertions all true;36 malformed variants rejected;23 inherited suite counts and Legacy identical; source/approval boundaries unchanged',
 'actual':'PASS in the bounded isolated proof scope; no manual/production acceptance claimed',
 'focused':load(out/'focused-summary.json'),
 'original_m4_regression':{'M401':[78,525],'M402':[55,1188],'M403A':[94,1165],'M403B':[150,3339],'M403C':[115,6054],'interpretation':'cases/assertions, original suites unchanged and rerun in both full suites'},
 'inherited_suite_counts':'23/23 equal; post-r54/regression-comparison.json','legacy':load(out/'legacy-comparison.json'),
 'source_integrity':{'runtime_test_runner_UIDs':'11/11 hashes equal across original tested/original delivery/new tested/current','protected_original_sources':'130/130 unchanged versus original recorded hash and new canonical','source_manifests':'candidate141/141 and canonical131/131 entries verified against snapshots and exact Git sources; see actual manifest counts if metadata differs','original_evidence':'all38 original top-level evidence artifacts byte-identical to old delivery; original evidence-sha256 retained unchanged','reports_logs':'logs.zip plus archive-entries.json hashes actual archived bytes'},
 'validator_audit':{'command':'python3 /tmp/g55_validator_audit.py','baseline_valid_report':True,'rejected':36,'report_stdout_variants':32,'process_variants':4,'actual_runner_closure':'AST-extracted unchanged run closure; deterministic nonzero/unexpected engine error/script error/timeout injections. Printed FAIL probe lines are expected rejections, not Godot regression failures.','details':'post-r54/validator-audit.json'},
 'runtime_review':{'O1':'valid rescue B1 and entry_round<current_round; B2 nonurgent; Safety first','O2':'budget / owner validated global creation history / stable party order; no Player favoritism/caller order/opaque ID decoding','O3':'ALIVE/PRESENT NPC current legal slot, active Enemy/nonterminal/higher priorities false, HP<=30%; RETREAT/self reason M404_SELF_PRESERVATION_RETREAT','O5':'separate exact12/exact8 recursive strict schemas/current owner equality; pure candidate never grants token/receipt; owned C transaction only','D16':'helper priority/inability/request rejection/actual post-lock SKIPPED distinct; no O4 consent/new Compassion behavior','protected_v1_R1':'unchanged; full inherited Guidance suites rerun'},
 'remaining':{'M404':'08/10/11/16/18/20 PARTIAL;15 DIAGNOSTIC-ONLY;17 BLOCKED DEPENDENCY;new design group22 mapped only to available slices and explicitly PARTIAL','M402':'06 BLOCKED /24 PARTIAL unchanged','M403':'10/14/15 DIAGNOSTIC;13/42 PARTIAL unchanged','O4':'conscious consent deferred','O6':'real HELP/DEFEND bridge blocked / pure policy only; nullable HELP authority unknown','O7':'legal mid-action external producers diagnostic/deferred; serial second Enemy hit does not close this gap','production':'no full D09/Pending/Player Command/Main/Legacy integration','manual_GUI_F5_F6_keyboard_visual':'NOT RUN'},
 'failed_attempts_and_corrections':[
  'Initial sandbox git fetch could not write FETCH_HEAD; ls-remote DNS unavailable. Retried with normal-access escalation; fetched/live refs verified before rebase.',
  'First GitHub list reviews call used repository_full_name instead of repo_full_name; connector schema rejected, corrected and independent review5818357540 read.',
  'First reconciliation helper searched a nonexistent current-subdecision heading; no code affected. Corrected to canonical Owner subdecisions heading and reran deterministic manual reconciliation; approved section/architecture compared.',
  'Initial local link audit ran before post-r54-rebase.json existed and correctly rejected seven links to the not-yet-generated artifact. Generated separate record, reran link audit. No runtime failure.',
  'Additional design mapping draft was checked against actual case-index and corrected before delivery; no test source/assertion changed.',
  'Original historical development failures remain in unchanged development-history.json/development.zip and are not post-rebase attempts.'
 ],
 'stop':'Draft PR55 — Updated onto PR54 Canonical / Awaiting Independent Follow-up Code & Evidence Review. DO NOT SQUASH MERGE / AUTO-MERGE / DELETE BRANCH / CREATE REPLACEMENT PR / START M4-05 / MODIFY PRODUCTION MAIN LEGACY GUIDANCE.'
}
# Correct totals from actual artifacts, never assumed.
record['source_integrity']['source_manifests']={label:len(load(d/'source-sha256.json')) for d,label in [(c,'canonical'),(f,'candidate')]}
record['source_integrity']['original_evidence_files_unchanged']=len(load(out/'original-evidence-integrity.json'))
write(base/'post-r54-rebase.json',record)
print('Packaged fresh canonical88/candidate94, inherited23, Legacy6/5892, focused128/458')
