from pathlib import Path
import subprocess,json,hashlib,re,unicodedata,urllib.parse,collections
root=Path.cwd();canon='6cd7b842c07e308203f61bbaaff6339233567c68';old='af3c4161a0d5e72bafec46ae07561be5ec1fdc7c';tested='abb0727a892127d4b43f880af5890d68859d7f86'
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(ref,p):return subprocess.check_output(['git','show',ref+':'+p])
evidence=Path('tests/actors/evidence/m4-04');post=evidence/'post-r54';post.mkdir(exist_ok=True)
def write(name,x):(post/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
protected=json.loads((evidence/'source-comparison.json').read_text())['protected_sha256'];rows=[]
for p,h in protected.items():
 hashes={'recorded_original':h,'new_canonical':sha(git(canon,p)),'new_tested':sha(git(tested,p)),'current':sha(Path(p).read_bytes())};assert len(set(hashes.values()))==1,p
 rows.append({'path':p,'sha256_by_source':hashes,'equal':True})
write('protected-source-comparison.json',rows)
original=[]
for p in sorted(evidence.iterdir()):
 if p.is_file() and p.name!='post-r54-rebase.json':
  h=sha(p.read_bytes());assert h==sha(git(old,str(p))),p
  original.append({'path':str(p),'sha256':h,'equal_original_delivery':True})
write('original-evidence-integrity.json',original)
write('source-comparison.json',json.loads(Path('/tmp/g55-source-comparison.json').read_text()))
# Retained pre-cutover source/results provenance is revalidated, never labelled a fresh engine run.
ref=Path('/tmp/wanderer-m3a04-reference-20261105-2');x=json.loads((evidence/'reference-provenance.json').read_text())
for row in x['tracked_source_matches']:
 assert sha(git(x['commit'],row['path']))==row['sha256']==sha((ref/'snapshot'/row['path']).read_bytes()),row['path']
assert json.loads((ref/'results.json').read_text())==json.loads(Path('tests/actors/evidence/m4-01/reference-results.json').read_text())
write('reference-provenance.json',{'commit':x['commit'],'tracked_source_count':len(x['tracked_source_matches']),'all_hashes_match':True,'reference_results_equal_durable':True,'engine_execution_rerun':False,'retained_reference':str(ref)})
# Local links and generated heading anchors, including explicit historical aliases.
paths=[Path(p) for p in ['README.md','docs/README.md','docs/M4_04_Autonomous_Decision_Contract.md','tests/actors/README.md','tests/combat/README.md']]
def anchors(p):
 text=p.read_text();found=set(re.findall(r'<a\s+(?:name|id)=[\"\x27]([^\"\x27]+)',text));counts={}
 for title in re.findall(r'^#{1,6}\s+(.+?)\s*#*$',text,re.M):
  title=re.sub(r'\[([^]]+)\]\([^)]*\)',r'\1',title).lower();title=re.sub(r'<[^>]+>','',title)
  slug=''.join(c for c in title if c in ' -_' or unicodedata.category(c)[0] in 'LNM').replace(' ','-')
  n=counts.get(slug,0);counts[slug]=n+1;found.add(slug+(f'-{n}' if n else ''))
 return found
errors=[];links=fragments=external=0
for p in paths:
 for url in re.findall(r'\[[^\]\n]*\]\(([^\s)]+)\)',p.read_text()):
  if re.match(r'\w+://',url):external+=1;continue
  name,_,frag=urllib.parse.unquote(url).partition('#');dest=(p.parent/name).resolve() if name else p.resolve();links+=1
  if not dest.exists():errors.append(f'{p}: missing {url}')
  elif frag:
   fragments+=1
   if frag not in anchors(dest):errors.append(f'{p}: fragment {url}')
p='docs/M4_04_Autonomous_Decision_Contract.md';a=git(canon,p).decode();b=Path(p).read_text();section=lambda s:s[s.index('### 2.1'):s.index('## 3.')]
assert section(a)==section(b)
p='docs/M4_Down_Help_Death_Retreat_Architecture.md';assert Path(p).read_bytes()==git(canon,p)
for p in paths:
 assert not re.search(r'^(<<<<<<< |=======|>>>>>>> )',p.read_text(),re.M),p
assert not errors,errors
write('documentation-audit.json',{'files':[str(p) for p in paths],'local_links':links,'fragments':fragments,'external_references':external,'external_HTTP':'not exhaustively checked; relevant PR states read through GitHub connector','errors':errors,'approved_section_2_1_byte_identical':True,'approved_section_2_1_sha256':sha(section(a).encode()),'architecture_byte_identical':True,'architecture_sha256':sha(Path('docs/M4_Down_Help_Death_Retreat_Architecture.md').read_bytes()),'conflict_markers':0,'current_authority_sections':'one current implementation status and one canonical approved register; historical checkpoints labelled','additional_21_23_mapping':'executed slices only, M404-22 explicitly PARTIAL','runtime_review':'O1/O2/O3/O5 inspected; no runtime/test changes; no new O4/trait/Compassion/production behavior'})
print(json.dumps({'protected':len(rows),'original_evidence_files_unchanged':len(original),'reference_source_hashes':len(x['tracked_source_matches']),'links':links,'fragments':fragments,'errors':errors},indent=2))
