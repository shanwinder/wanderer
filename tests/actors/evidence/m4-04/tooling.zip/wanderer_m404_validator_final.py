import json,copy,importlib.util,tempfile
from pathlib import Path
spec=importlib.util.spec_from_file_location('verify','tests/combat/verify.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
out=Path('/tmp/wanderer-m404-final-20261108-3'); report=json.loads((out/'m4-04-scenarios.json').read_text());log=(out/'m4-autonomous-decision-proof.log').read_text();source=out/'snapshot'
p=Path('/tmp/wanderer-m404-validator-report.json');p.write_text(json.dumps(report));assert v.validate_m404_report(p,log,source)
results=[]
def reject(name,x=None,txt=None,stdout=log):
 p.write_text(json.dumps(x) if txt is None else txt)
 ok=not v.validate_m404_report(p,stdout,source);results.append({'variant':name,'rejected':ok});assert ok,name
for key in report:
 x=copy.deepcopy(report);x.pop(key);reject('missing_'+key,x)
for key in ['independent_cases','assertion_checks','failures','per_frame_checks']:
 x=copy.deepcopy(report);x[key]=False;reject('bool_'+key,x)
for key,val in [('id','M404-001'),('classification','NOT RUN'),('assertion_count',0),('failure_count',1),('actual','FAIL')]:
 x=copy.deepcopy(report);x['cases'][1][key]=val;reject('case_'+key,x)
for val in [False,1,'true',None]:
 x=copy.deepcopy(report);x['cases'][0]['assertions'][0]['passed']=val;reject('assertion_'+repr(val),x)
x=copy.deepcopy(report);x['cases'][0]['steps'][0]['actual_reason']='FORGED';reject('reason_mismatch',x)
x=copy.deepcopy(report);x['source_sha256'][next(iter(x['source_sha256']))]='0'*64;reject('source_forgery',x)
x=copy.deepcopy(report);x['cases'].pop();x['independent_cases']-=1;reject('hidden_case',x)
for txt in ['{','null','{"suite": NaN}','{"suite":1,"suite":2}'] :reject('bad_json_'+txt,txt=txt)
for name,l in [('missing_stdout',''),('missing_case_line',log.replace('CASE M404-001: PASS\n','')),('duplicate_result',log+'RESULT: 1 checks, 0 failures\n')]:reject(name,report,stdout=l)
p.unlink();assert not v.validate_m404_report(p,log,source);results.append({'variant':'missing_report','rejected':True})
Path('/tmp/wanderer-m404-validator-audit.json').write_text(json.dumps(results,indent=2)+'\n');print(f'{len(results)} malformed-report/stdout variants rejected')

# Exercise the actual runner closure with deterministic process-result fault injection.
import ast,types,subprocess,re
module=ast.parse(Path('tests/combat/verify.py').read_text())
main=next(n for n in module.body if isinstance(n,ast.FunctionDef) and n.name=='main')
run_node=next(n for n in main.body if isinstance(n,ast.FunctionDef) and n.name=='run')
for name,code,stdout,timeout in [('nonzero',1,'',False),('unexpected-error',0,'ERROR: injected engine error\n',False),('script-error',0,'SCRIPT ERROR: injected parse error\n',False),('timeout',0,'',True)]:
 def simulated(*a,**kw):
  if timeout: raise subprocess.TimeoutExpired('fake',300,output=b'partial')
  return types.SimpleNamespace(stdout=stdout,returncode=code)
 temp=Path(tempfile.mkdtemp(prefix='m404-wrapper-audit-'))
 env={'subprocess':types.SimpleNamespace(run=simulated,TimeoutExpired=subprocess.TimeoutExpired,PIPE=subprocess.PIPE,STDOUT=subprocess.STDOUT),'args':types.SimpleNamespace(godot='fault-injected'),'snapshot':source,'output':temp,'results':[],'re':re,'json':json}
 exec(compile(ast.Module(body=[run_node],type_ignores=[]),'<actual-runner-closure>','exec'),env)
 assert env['run']('probe',[]) is False
 results.append({'variant':'process_'+name,'rejected':True,'result':env['results'][0]})
Path('/tmp/wanderer-m404-validator-audit.json').write_text(json.dumps(results,indent=2)+'\n')
print(str(len(results))+' total report/process variants rejected')
