from pathlib import Path
import re,unicodedata,subprocess,json,hashlib,zipfile
paths=[Path(p) for p in ['README.md','docs/README.md','docs/M4_04_Autonomous_Decision_Contract.md','tests/actors/README.md','tests/combat/README.md']]
def anchors(p):
 text=p.read_text();found=set(re.findall(r'<a\s+(?:name|id)=[\"\x27]([^\"\x27]+)',text));counts={}
 for title in re.findall(r'^#{1,6}\s+(.+?)\s*#*$',text,re.M):
  title=re.sub(r'\[([^]]+)\]\([^)]*\)',r'\1',title).lower();title=re.sub(r'<[^>]+>','',title)
  slug=''.join(c for c in title if c in ' -_' or unicodedata.category(c)[0] in 'LNM').replace(' ','-')
  n=counts.get(slug,0);counts[slug]=n+1;found.add(slug+(f'-{n}' if n else ''))
 return found
errors=[];links=frags=0
for p in paths:
 for url in re.findall(r'\[[^\]\n]*\]\(([^\s)]+)\)',p.read_text()):
  if re.match(r'\w+://',url):continue
  name,_,frag=url.partition('#');dest=(p.parent/name).resolve() if name else p.resolve();links+=1
  if not dest.exists():errors.append(f'{p}: missing {url}')
  elif frag:
   frags+=1
   if frag not in anchors(dest):errors.append(f'{p}: fragment {url}')
base='0c5eef193da6265d1e7f502123711ba4753625ce';tested='6187a4ff6dea0a5a983c21171e92db53eff6cd63'
changed=set(subprocess.check_output(['git','diff','--name-only',base],text=True).splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines())
allowed={str(p) for p in paths}|{'tests/combat/verify.py','tests/actors/m4_04_autonomous_decision_proof.gd','tests/actors/m4_04_autonomous_decision_proof.gd.uid'}
for p in changed:
 if p in allowed or p.startswith('tests/actors/evidence/m4-04/') or (p.startswith('scripts/m4/m404_') and Path(p).suffix in ['.gd','.uid']):continue
 errors.append('out of scope '+p)
posttest=set(subprocess.check_output(['git','diff','--name-only',tested],text=True).splitlines())
if any(p not in {str(f) for f in paths} and not p.startswith('tests/actors/evidence/m4-04/') for p in posttest):errors.append('post-test delta not docs/evidence-only '+repr(posttest))
# Original architecture is wholly protected in this implementation task.
assert Path('docs/M4_Down_Help_Death_Retreat_Architecture.md').read_bytes()==subprocess.check_output(['git','show',base+':docs/M4_Down_Help_Death_Retreat_Architecture.md'])
for n in ['canonical-results.json','final-results.json']:
 r=json.load(open('tests/actors/evidence/m4-04/'+n));assert all(x['status']=='PASS' for x in r)
result={'markdown_files':len(paths),'local_links':links,'fragments':frags,'errors':errors,'scope_paths':sorted(changed),'post_test_tracked_delta':sorted(posttest),'architecture_original':'byte-identical','external_http_check':'not exhaustive','diff_check':'PASS' if subprocess.run(['git','diff','--check']).returncode==0 else 'FAIL'}
Path('tests/actors/evidence/m4-04/review-checks.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='scope_paths'},indent=2));assert not errors,errors
