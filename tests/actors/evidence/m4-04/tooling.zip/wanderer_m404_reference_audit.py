from pathlib import Path
import json,hashlib,subprocess,zipfile
out=Path('tests/actors/evidence/m4-04');ref=Path('/tmp/wanderer-m3a04-reference-20261105-2')
x=json.load(open('tests/actors/evidence/m4-03c/reference-provenance.json'));bad=[]
for row in x['tracked_source_matches']:
 raw=subprocess.check_output(['git','show',x['commit']+':'+row['path']]);actual=hashlib.sha256(raw).hexdigest()
 snapshot=ref/'snapshot'/row['path']
 if actual!=row['sha256'] or not snapshot.exists() or hashlib.sha256(snapshot.read_bytes()).hexdigest()!=actual:bad.append(row['path'])
assert not bad,bad
r=json.load(open(ref/'results.json'));durable=json.load(open('tests/actors/evidence/m4-01/reference-results.json'));assert r==durable
x['revalidated_in_m404']=True;x['revalidated_tracked_source_count']=len(x['tracked_source_matches']);x['reference_results_equal_durable']=True;x['engine_execution_rerun']=False
(out/'reference-provenance.json').write_text(json.dumps(x,indent=2)+'\n')
r=json.load(open(out/'run-record.json'));r['commands']['candidate']=r['commands']['canonical'].replace('/tmp/wanderer-m404-canonical-20261108-2','/tmp/wanderer-m404-final-20261108-3').replace(' --cutover-baseline',' --m4-autonomous-decision-proof --cutover-baseline');r['strict_validator_variants_rejected']=36;r['documentation_audit']={'files':5,'local_links':398,'fragments':88,'errors':0};(out/'run-record.json').write_text(json.dumps(r,indent=2,ensure_ascii=False)+'\n')
x=json.load(open(out/'development-history.json'));x['packaging_audit_correction']='Initial reference audit assumed source-sha256.json existed in old44-stage output; missing file caught. Corrected to hash actual retained snapshot files against git commit and inherited hash record. No engine PASS fabricated.';(out/'development-history.json').write_text(json.dumps(x,indent=2)+'\n')
with zipfile.ZipFile(out/'tooling.zip','a',zipfile.ZIP_DEFLATED) as z:
 for f in ['/tmp/wanderer_m404_final_audit.py','/tmp/wanderer_m404_reference_audit.py']:z.write(f,Path(f).name)
print('Reference provenance revalidated:',len(x.get('tracked_source_matches',[])))
