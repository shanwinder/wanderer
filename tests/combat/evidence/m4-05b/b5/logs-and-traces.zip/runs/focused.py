import hashlib,json,re,subprocess,sys
from pathlib import Path
root=Path(sys.argv[1])
root.mkdir()
project=Path.cwd()
godot='/Applications/Godot.app/Contents/MacOS/Godot'
smoke='/private/tmp/wanderer-b3-focused-final2/original-smoke.gd'
assert hashlib.sha256(Path(smoke).read_bytes()).hexdigest()=='d3110f88a368f048a8500fc57cf8e6a015fa8744e23cfb169ab881a3a7b3bdfe'
proof='res://tests/combat/m4_05_playable_scene_proof.gd'
authority='res://tests/actors/m4_05_playable_authority_proof.gd'
stages=[]
def run(name, args, pattern=None, code=0):
    log=root/(name+'.log')
    command=[godot,'--headless','--path',str(project),'--log-file',str(root/(name+'.engine.log')),*args]
    try:
        with log.open('w') as dest:
            result=subprocess.run(command,stdout=dest,stderr=subprocess.STDOUT,timeout=900)
        exit_code=result.returncode
    except subprocess.TimeoutExpired:
        exit_code=None
    logtext=log.read_text()
    errors=[l for l in logtext.splitlines() if re.match(r'^\s*(SCRIPT ERROR|ERROR):',l)]
    valid=exit_code==code and not errors and (pattern is None or re.search(pattern,logtext) is not None)
    stages.append(dict(stage=name,command=command,exit=exit_code,errors=errors,passed=valid,expected=pattern))
    (root/'results.json').write_text(json.dumps(stages,indent=2)+'\n')
    print(name,exit_code,valid,flush=True)
    return valid
def report(name, script, expected, *args):
    return run(name,['--script',script,'--','--report='+str(root/(name+'.json')),*args],expected)
run('version',['--version'],r'^4\.7\.2\.stable\.official\.ed1daf0bf')
run('import',['--editor','--import'])
for file in ['res://scripts/combat/m4_playable_controller.gd','res://scripts/combat/m4_playable_presentation_adapter.gd',proof]:
    run('parse-'+file.rsplit('/',1)[-1],['--check-only','--script',file])
run('standalone-startup',['--quit-after','120','res://scenes/combat/combat_m4_playable_optin.tscn'])
report('b1-smoke',smoke,r'PASS checks=86\b')
report('b1-expanded',authority,r'PASS checks=97\b')
report('b1-schema',authority,r'PASS checks=1907\b','--gate=D')
report('b1-transactions',authority,r'PASS checks=354\b','--gate=E')
report('b2','res://tests/actors/m4_05_playable_effect_proof.gd',r'PASS checks=1031\b')
report('b3','res://tests/actors/m4_05_playable_lifecycle_proof.gd',r'PASS checks=2507\b')
report('b4','res://tests/actors/m4_05_playable_event_proof.gd',r'PASS checks=4238\b')
sys.exit(int(not all(stage['passed'] for stage in stages)))
