extends SceneTree
const Owner = preload("res://scripts/m4/playable_encounter.gd")
const Rules = preload("res://scripts/m4/playable_rules.gd")
const C = preload("res://scripts/m4/playable_contract.gd")
var factory = RefCounted.new()
var input_cap = RefCounted.new()
var driver = RefCounted.new()
var presenter = RefCounted.new()
var checks: Array = []
var history: Array = []
var sequence: int = 0
var failed: bool = false

func check(ok: bool, label: String) -> void:
	checks.append({"label": label, "passed": ok})
	if not ok:
		failed = true
		print("FAIL: " + label)

func request(e, operation: String, payload: Dictionary = {}, issuer: String = "DRIVER") -> Dictionary:
	sequence += 1
	var v: Dictionary = e.read_view()
	return {"domain": "M4_PLAYABLE", "version": 1, "identity": v.identity, "queue_id": v.queue_id,
		"request_id": ("ui/" if issuer == "INPUT" else "driver/") + str(sequence), "issuer": issuer, "operation": operation, "payload": payload}

func call_tx(e, operation: String, payload: Dictionary = {}, issuer: String = "DRIVER") -> Dictionary:
	var before: Dictionary = e.snapshot()
	var req: Dictionary = request(e, operation, payload, issuer)
	var result: Dictionary = e.transact(req, input_cap if issuer == "INPUT" else driver)
	check(C.response_valid(operation, result), operation + " exact response")
	check(e.replay_matches(), operation + " replay equality")
	history.append({"request": req, "response": result, "before": before, "after": e.snapshot()})
	return result

func _initialize() -> void:
	var e = Owner.new(factory, input_cap, driver, presenter)
	var boot: Dictionary = e.bootstrap({"domain": "M4_PLAYABLE", "version": 1, "fixture_id": "m405-demo/main", "fixture_version": 1}, factory)
	check(boot.status == "CREATED", "catalog bootstrap")
	check(e.replay_matches(), "bootstrap replay")
	var root_before: Dictionary = e.snapshot()
	var reject: Dictionary = call_tx(e, "ADMIT")
	check(reject.reason == "M405_COMMAND_REQUIRED" and e.snapshot() == root_before, "eligible Player requires command with full-root equality")
	var command: Dictionary = call_tx(e, "COMMAND", {"actor_id": "player", "action": "ATTACK", "target_id": "enemy_a"}, "INPUT")
	check(command.status == "ACCEPTED" and command.view.has_accepted_fresh_command and not command.view.command_ready, "real accepted command freshness")
	var admitted: Dictionary = call_tx(e, "ADMIT")
	check(admitted.status == "APPLIED", "admission")
	if admitted.status == "APPLIED":
		for index in range(6):
			var s: Dictionary = Rules.slot(e.snapshot())
			var op: String = "PLAYER_LOCK" if index == 0 else ("DECIDE_LOCK" if index < 4 else "ENEMY_LOCK")
			var payload: Dictionary = {"observation": e.read_observation()} if op == "DECIDE_LOCK" else {"slot_id": s.slot_id}
			var locked: Dictionary = call_tx(e, op, payload)
			check(locked.status == "AUTHORIZED", "real slot lock " + str(index))
			if locked.status != "AUTHORIZED": break
			var token: Dictionary = locked.token
			if token.kind != "ATTACK":
				var cancelled: Dictionary = call_tx(e, "CANCEL", {"token": token})
				check(cancelled.status == "APPLIED" and cancelled.receipt == null, "cancel policy-selected non-Attack without fake receipt")
				continue
			var pre: Dictionary = e.snapshot()
			var impact: Dictionary = call_tx(e, "IMPACT", {"token": token})
			check(impact.status in ["APPLIED", "SKIPPED"], "real impact")
			if impact.status == "APPLIED": check(impact.effect.hp_delta == -Rules.damage(token.actor_id), "actual damage " + token.actor_id)
			var after: Dictionary = e.snapshot()
			var duplicate: Dictionary = call_tx(e, "IMPACT", {"token": token})
			check(duplicate.status == "REJECTED" and e.snapshot() == after, "duplicate impact full-root equality")
			var complete: Dictionary = call_tx(e, "COMPLETE", {"token": token})
			check(complete.status == "COMPLETED" and complete.receipt != null, "genuine completion receipt")
			check(pre.receipts.size() + 1 == e.snapshot().receipts.size(), "exactly one receipt")
	var report: Dictionary = {"checks": checks, "history": history, "final_root": e.snapshot(), "status": "FAIL" if failed else "PASS", "coverage": "Initial real transaction smoke only; full adversarial matrix not yet executed"}
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--report="):
			var f = FileAccess.open(arg.substr(9), FileAccess.WRITE)
			f.store_string(JSON.stringify(report, "\t"))
	print("B1 INITIAL PROOF: " + report.status + " checks=" + str(checks.size()))
	quit(1 if failed else 0)
