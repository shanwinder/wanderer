from pathlib import Path
import hashlib, json, re, subprocess, sys

run = Path('/tmp/wanderer-hud-fix.xquk9A')
source = run / 'focused-source'
out = run / 'focused'
out.mkdir()
godot = '/Applications/Godot.app/Contents/MacOS/Godot'
proof = 'res://tests/actors/m4_05_playable_authority_proof.gd'
stages = [
 ('version', ['--version'], r'^4\.7\.2\.stable\.official\.ed1daf0bf'),
 ('import', ['--editor','--import'], None),
 *[(f'parse-{Path(p).stem}', ['--check-only','--script',p],None) for p in [
  'res://scripts/combat/m4_playable_controller.gd','res://scripts/combat/m4_playable_presentation_adapter.gd',
  'res://tests/combat/m4_05_playable_scene_proof.gd','res://tests/combat/m4_05_playable_keyboard_proof.gd']],
 ('standalone-startup',['--quit-after','120','res://scenes/combat/combat_m4_playable_optin.tscn'],None),
]
for name, script, options, expect in [
 ('b1-smoke',str(run/'original-smoke.gd'),[],r'PASS checks=86\b'),
 ('b1-expanded',proof,[],r'PASS checks=97\b'),
 ('b1-schema',proof,['--gate=D'],r'PASS checks=1907\b'),
 ('b1-transactions',proof,['--gate=E'],r'PASS checks=354\b'),
 ('b2','res://tests/actors/m4_05_playable_effect_proof.gd',[],r'PASS checks=1031\b'),
 ('b3','res://tests/actors/m4_05_playable_lifecycle_proof.gd',[],r'PASS checks=2507\b'),
 ('b4','res://tests/actors/m4_05_playable_event_proof.gd',[],r'^B4 EVENT PROOF: checks=4238 failures=0 transactions=474 streams=28$'),
 ('b5','res://tests/combat/m4_05_playable_scene_proof.gd',[],r'^B5 SCENE PROOF: PASS checks=1521 failures=0$'),
 ('keyboard','res://tests/combat/m4_05_playable_keyboard_proof.gd',[],r'^B5 KEYBOARD PROOF: PASS checks=81 failures=0$'),
]:
    stages.append((name,['--script',script,'--',f'--report={out / (name + ".json")}',*options],expect))
results=[]
for name, args, expect in stages:
    engine=out/(name+'.engine.log')
    command=[godot,'--headless','--path',str(source),'--log-file',str(engine),*args]
    timed_out=False
    try:
        proc=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=420)
        data,code=proc.stdout,proc.returncode
    except subprocess.TimeoutExpired as err:
        data,code=err.stdout or b'',124
        timed_out=True
    (out/(name+'.log')).write_bytes(data)
    (out/(name+'.exit')).write_text(str(code)+'\n')
    console=data.decode('utf-8','replace')
    engine_text=engine.read_text(errors='replace') if engine.exists() else ''
    pattern=r'^\s*(?:SCRIPT ERROR|ERROR):[^\n]+'
    errors=sorted({line.strip() for value in (console,engine_text) for line in re.findall(pattern,value,re.M)})
    passed=code==0 and not errors and (expect is None or re.search(expect,console,re.M) is not None)
    results.append(dict(stage=name,command=command,expected=expect,exit=code,timeout=timed_out,errors=errors,passed=passed,
        summary=[line for line in console.splitlines() if 'checks=' in line][-2:]))
    (out/'results.json').write_text(json.dumps(results,indent=2,ensure_ascii=False)+'\n')
    print(name,'PASS' if passed else 'FAIL',code,flush=True)
sys.exit(not all(r['passed'] for r in results))
